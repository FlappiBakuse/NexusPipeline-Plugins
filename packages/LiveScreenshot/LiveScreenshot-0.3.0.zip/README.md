# 实时截图窗口

`live-screenshot` v0.2.0 在调度中心每个运行任务卡片的 sidecar 区域显示当前游戏画面，并声明 `execution-preview-client` 能力；前端文案通过插件自有词典支持 zh-CN/en-US。PC 模式由宿主按运行时识别到的游戏进程捕获客户区，模拟器模式由宿主内置的 MuMuManager 或 Generic ADB 驱动获取设备画面；插件前端不会提交进程、窗口或 ADB 目标。

预览输出保持原始宽高比，高度最高 360 像素并编码为 JPEG；运行期间每 5 秒采样一次，任务结束后清理计时器、请求和 Object URL。前端使用 Frontend API 1.5，只消费公开 `nxp-*` 组件与宿主 `--nx-*` design token。
