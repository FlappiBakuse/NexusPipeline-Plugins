//#region ../../../../node_modules/@vue/shared/dist/shared.esm-bundler.js
// @__NO_SIDE_EFFECTS__
function e(e) {
	let t = /* @__PURE__ */ Object.create(null);
	for (let n of e.split(",")) t[n] = 1;
	return (e) => e in t;
}
var t = {}, n = [], r = () => {}, i = () => !1, a = (e) => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && (e.charCodeAt(2) > 122 || e.charCodeAt(2) < 97), o = (e) => e.startsWith("onUpdate:"), s = Object.assign, c = (e, t) => {
	let n = e.indexOf(t);
	n > -1 && e.splice(n, 1);
}, l = Object.prototype.hasOwnProperty, u = (e, t) => l.call(e, t), d = Array.isArray, f = (e) => x(e) === "[object Map]", p = (e) => x(e) === "[object Set]", m = (e) => x(e) === "[object Date]", h = (e) => typeof e == "function", g = (e) => typeof e == "string", _ = (e) => typeof e == "symbol", v = (e) => typeof e == "object" && !!e, y = (e) => (v(e) || h(e)) && h(e.then) && h(e.catch), b = Object.prototype.toString, x = (e) => b.call(e), S = (e) => x(e).slice(8, -1), C = (e) => x(e) === "[object Object]", w = (e) => g(e) && e !== "NaN" && e[0] !== "-" && "" + parseInt(e, 10) === e, ee = /* @__PURE__ */ e(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"), te = (e) => {
	let t = /* @__PURE__ */ Object.create(null);
	return ((n) => t[n] || (t[n] = e(n)));
}, ne = /-\w/g, T = te((e) => e.replace(ne, (e) => e.slice(1).toUpperCase())), re = /\B([A-Z])/g, E = te((e) => e.replace(re, "-$1").toLowerCase()), ie = te((e) => e.charAt(0).toUpperCase() + e.slice(1)), ae = te((e) => e ? `on${ie(e)}` : ""), D = (e, t) => !Object.is(e, t), oe = (e, ...t) => {
	for (let n = 0; n < e.length; n++) e[n](...t);
}, O = (e, t, n, r = !1) => {
	Object.defineProperty(e, t, {
		configurable: !0,
		enumerable: !1,
		writable: r,
		value: n
	});
}, se = (e) => {
	let t = parseFloat(e);
	return isNaN(t) ? e : t;
}, ce, le = () => ce ||= typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : typeof global < "u" ? global : {};
function ue(e) {
	if (d(e)) {
		let t = {};
		for (let n = 0; n < e.length; n++) {
			let r = e[n], i = g(r) ? me(r) : ue(r);
			if (i) for (let e in i) t[e] = i[e];
		}
		return t;
	}
	if (g(e) || v(e)) return e;
}
var de = /;(?![^(]*\))/g, fe = /:([^]+)/, pe = /\/\*[^]*?\*\//g;
function me(e) {
	let t = {};
	return e.replace(pe, "").split(de).forEach((e) => {
		if (e) {
			let n = e.split(fe);
			n.length > 1 && (t[n[0].trim()] = n[1].trim());
		}
	}), t;
}
function k(e) {
	let t = "";
	if (g(e)) t = e;
	else if (d(e)) for (let n = 0; n < e.length; n++) {
		let r = k(e[n]);
		r && (t += r + " ");
	}
	else if (v(e)) for (let n in e) e[n] && (t += n + " ");
	return t.trim();
}
var he = "itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly", ge = /* @__PURE__ */ e(he);
he + "";
function _e(e) {
	return !!e || e === "";
}
function ve(e, t) {
	if (e.length !== t.length) return !1;
	let n = !0;
	for (let r = 0; n && r < e.length; r++) n = be(e[r], t[r]);
	return n;
}
function ye(e, t) {
	if (e.size !== t.size) return !1;
	let n = Array.from(t), r = new Uint8Array(n.length);
	for (let t of e) {
		let e = -1;
		for (let i = 0; i < n.length; i++) if (!r[i] && be(t, n[i])) {
			e = i;
			break;
		}
		if (e < 0) return !1;
		r[e] = 1;
	}
	return !0;
}
function be(e, t) {
	if (e === t) return !0;
	let n = m(e), r = m(t);
	if (n || r) return n && r ? e.getTime() === t.getTime() : !1;
	if (n = _(e), r = _(t), n || r) return e === t;
	if (n = d(e), r = d(t), n || r) return n && r ? ve(e, t) : !1;
	if (n = v(e), r = v(t), n || r) {
		if (!n || !r) return !1;
		if (n = f(e), r = f(t), n || r || (n = p(e), r = p(t), n || r)) return n && r ? ye(e, t) : !1;
		if (Object.keys(e).length !== Object.keys(t).length) return !1;
		for (let n in e) {
			let r = e.hasOwnProperty(n), i = t.hasOwnProperty(n);
			if (r && !i || !r && i || !be(e[n], t[n])) return !1;
		}
	}
	return String(e) === String(t);
}
var xe = (e) => !!(e && e.__v_isRef === !0), A = (e) => g(e) ? e : e == null ? "" : d(e) || v(e) && (e.toString === b || !h(e.toString)) ? xe(e) ? A(e.value) : JSON.stringify(e, Se, 2) : String(e), Se = (e, t) => xe(t) ? Se(e, t.value) : f(t) ? { [`Map(${t.size})`]: [...t.entries()].reduce((e, [t, n], r) => (e[Ce(t, r) + " =>"] = n, e), {}) } : p(t) ? { [`Set(${t.size})`]: [...t.values()].map((e) => Ce(e)) } : _(t) ? Ce(t) : v(t) && !d(t) && !C(t) ? String(t) : t, Ce = (e, t = "") => _(e) ? `Symbol(${e.description ?? t})` : e, j, we = class {
	constructor(e = !1) {
		this.detached = e, this._active = !0, this._on = 0, this.effects = [], this.cleanups = [], this._isPaused = !1, this._warnOnRun = !0, this.__v_skip = !0, !e && j && (j.active ? (this.parent = j, this.index = (j.scopes || (j.scopes = [])).push(this) - 1) : (this._active = !1, this._warnOnRun = !1));
	}
	get active() {
		return this._active;
	}
	pause() {
		if (this._active) {
			this._isPaused = !0;
			let e, t;
			if (this.scopes) {
				let n = this.scopes.slice();
				for (e = 0, t = n.length; e < t; e++) n[e].pause();
			}
			for (e = 0, t = this.effects.length; e < t; e++) this.effects[e].pause();
		}
	}
	resume() {
		if (this._active && this._isPaused) {
			this._isPaused = !1;
			let e, t;
			if (this.scopes) {
				let n = this.scopes.slice();
				for (e = 0, t = n.length; e < t; e++) n[e].resume();
			}
			let n = this.effects.slice();
			for (e = 0, t = n.length; e < t; e++) n[e].resume();
		}
	}
	run(e) {
		if (this._active) {
			let t = j;
			try {
				return j = this, e();
			} finally {
				j = t;
			}
		}
	}
	on() {
		++this._on === 1 && (this.prevScope = j, j = this);
	}
	off() {
		if (this._on > 0 && --this._on === 0) {
			if (j === this) j = this.prevScope;
			else {
				let e = j;
				for (; e;) {
					if (e.prevScope === this) {
						e.prevScope = this.prevScope;
						break;
					}
					e = e.prevScope;
				}
			}
			this.prevScope = void 0;
		}
	}
	stop(e) {
		if (this._active) {
			this._active = !1;
			let t, n;
			for (t = 0, n = this.effects.length; t < n; t++) this.effects[t].stop();
			for (this.effects.length = 0, t = 0, n = this.cleanups.length; t < n; t++) this.cleanups[t]();
			if (this.cleanups.length = 0, this.scopes) {
				let e = this.scopes.slice();
				for (t = 0, n = e.length; t < n; t++) e[t].stop(!0);
				this.scopes.length = 0;
			}
			if (!this.detached && this.parent && !e) {
				let e = this.parent.scopes.pop();
				e && e !== this && (this.parent.scopes[this.index] = e, e.index = this.index);
			}
			this.parent = void 0;
		}
	}
};
function Te() {
	return j;
}
var M, Ee = /* @__PURE__ */ new WeakSet(), De = class {
	constructor(e) {
		this.fn = e, this.deps = void 0, this.depsTail = void 0, this.flags = 5, this.next = void 0, this.cleanup = void 0, this.scheduler = void 0, j && (j.active ? j.effects.push(this) : this.flags &= -2);
	}
	pause() {
		this.flags |= 64;
	}
	resume() {
		this.flags & 64 && (this.flags &= -65, Ee.has(this) && (Ee.delete(this), this.trigger()));
	}
	notify() {
		this.flags & 2 && !(this.flags & 32) || this.flags & 8 || je(this);
	}
	run() {
		if (!(this.flags & 1)) return this.fn();
		this.flags |= 2, Ue(this), Pe(this);
		let e = M, t = N;
		M = this, N = !0;
		try {
			return this.fn();
		} finally {
			Fe(this), M = e, N = t, this.flags &= -3;
		}
	}
	stop() {
		if (this.flags & 1) {
			for (let e = this.deps; e; e = e.nextDep) Re(e);
			this.deps = this.depsTail = void 0, Ue(this), this.onStop && this.onStop(), this.flags &= -2;
		}
	}
	trigger() {
		this.flags & 64 ? Ee.add(this) : this.scheduler ? this.scheduler() : this.runIfDirty();
	}
	runIfDirty() {
		Ie(this) && this.run();
	}
	get dirty() {
		return Ie(this);
	}
}, Oe = 0, ke, Ae;
function je(e, t = !1) {
	if (e.flags |= 8, t) {
		e.next = Ae, Ae = e;
		return;
	}
	e.next = ke, ke = e;
}
function Me() {
	Oe++;
}
function Ne() {
	if (--Oe > 0) return;
	if (Ae) {
		let e = Ae;
		for (Ae = void 0; e;) {
			let t = e.next;
			e.next = void 0, e.flags &= -9, e = t;
		}
	}
	let e;
	for (; ke;) {
		let t = ke;
		for (ke = void 0; t;) {
			let n = t.next;
			if (t.next = void 0, t.flags &= -9, t.flags & 1) try {
				t.trigger();
			} catch (t) {
				e ||= t;
			}
			t = n;
		}
	}
	if (e) throw e;
}
function Pe(e) {
	for (let t = e.deps; t; t = t.nextDep) t.version = -1, t.prevActiveLink = t.dep.activeLink, t.dep.activeLink = t;
}
function Fe(e) {
	let t, n = e.depsTail, r = n;
	for (; r;) {
		let e = r.prevDep;
		r.version === -1 ? (r === n && (n = e), Re(r), ze(r)) : t = r, r.dep.activeLink = r.prevActiveLink, r.prevActiveLink = void 0, r = e;
	}
	e.deps = t, e.depsTail = n;
}
function Ie(e) {
	for (let t = e.deps; t; t = t.nextDep) if (t.dep.version !== t.version || t.dep.computed && (Le(t.dep.computed) || t.dep.version !== t.version)) return !0;
	return !!e._dirty;
}
function Le(e) {
	if (e.flags & 4 && !(e.flags & 16) || (e.flags &= -17, e.globalVersion === We) || (e.globalVersion = We, !e.isSSR && e.flags & 128 && (!e.deps && !e._dirty || !Ie(e)))) return;
	e.flags |= 2;
	let t = e.dep, n = M, r = N;
	M = e, N = !0;
	try {
		Pe(e);
		let n = e.fn(e._value);
		(t.version === 0 || D(n, e._value)) && (e.flags |= 128, e._value = n, t.version++);
	} catch (e) {
		throw t.version++, e;
	} finally {
		M = n, N = r, Fe(e), e.flags &= -3;
	}
}
function Re(e, t = !1) {
	let { dep: n, prevSub: r, nextSub: i } = e;
	if (r && (r.nextSub = i, e.prevSub = void 0), i && (i.prevSub = r, e.nextSub = void 0), n.subs === e && (n.subs = r, !r && n.computed)) {
		n.computed.flags &= -5;
		for (let e = n.computed.deps; e; e = e.nextDep) Re(e, !0);
	}
	!t && !--n.sc && n.map && n.map.delete(n.key);
}
function ze(e) {
	let { prevDep: t, nextDep: n } = e;
	t && (t.nextDep = n, e.prevDep = void 0), n && (n.prevDep = t, e.nextDep = void 0);
}
var N = !0, Be = [];
function Ve() {
	Be.push(N), N = !1;
}
function He() {
	let e = Be.pop();
	N = e === void 0 || e;
}
function Ue(e) {
	let { cleanup: t } = e;
	if (e.cleanup = void 0, t) {
		let e = M;
		M = void 0;
		try {
			t();
		} finally {
			M = e;
		}
	}
}
var We = 0, Ge = class {
	constructor(e, t) {
		this.sub = e, this.dep = t, this.version = t.version, this.nextDep = this.prevDep = this.nextSub = this.prevSub = this.prevActiveLink = void 0;
	}
}, Ke = class {
	constructor(e) {
		this.computed = e, this.version = 0, this.activeLink = void 0, this.subs = void 0, this.map = void 0, this.key = void 0, this.sc = 0, this.__v_skip = !0;
	}
	track(e) {
		if (!M || !N || M === this.computed) return;
		let t = this.activeLink;
		if (t === void 0 || t.sub !== M) t = this.activeLink = new Ge(M, this), M.deps ? (t.prevDep = M.depsTail, M.depsTail.nextDep = t, M.depsTail = t) : M.deps = M.depsTail = t, qe(t);
		else if (t.version === -1 && (t.version = this.version, t.nextDep)) {
			let e = t.nextDep;
			e.prevDep = t.prevDep, t.prevDep && (t.prevDep.nextDep = e), t.prevDep = M.depsTail, t.nextDep = void 0, M.depsTail.nextDep = t, M.depsTail = t, M.deps === t && (M.deps = e);
		}
		return t;
	}
	trigger(e) {
		this.version++, We++, this.notify(e);
	}
	notify(e) {
		Me();
		try {
			for (let e = this.subs; e; e = e.prevSub) e.sub.notify() && e.sub.dep.notify();
		} finally {
			Ne();
		}
	}
};
function qe(e) {
	if (e.dep.sc++, e.sub.flags & 4) {
		let t = e.dep.computed;
		if (t && !e.dep.subs) {
			t.flags |= 20;
			for (let e = t.deps; e; e = e.nextDep) qe(e);
		}
		let n = e.dep.subs;
		n !== e && (e.prevSub = n, n && (n.nextSub = e)), e.dep.subs = e;
	}
}
var Je = /* @__PURE__ */ new WeakMap(), Ye = /* @__PURE__ */ Symbol(""), Xe = /* @__PURE__ */ Symbol(""), Ze = /* @__PURE__ */ Symbol("");
function P(e, t, n) {
	if (N && M) {
		let t = Je.get(e);
		t || Je.set(e, t = /* @__PURE__ */ new Map());
		let r = t.get(n);
		r || (t.set(n, r = new Ke()), r.map = t, r.key = n), r.track();
	}
}
function Qe(e, t, n, r, i, a) {
	let o = Je.get(e);
	if (!o) {
		We++;
		return;
	}
	let s = (e) => {
		e && e.trigger();
	};
	if (Me(), t === "clear") o.forEach(s);
	else {
		let i = d(e), a = i && w(n);
		if (i && n === "length") {
			let e = Number(r);
			o.forEach((t, n) => {
				(n === "length" || n === Ze || !_(n) && n >= e) && s(t);
			});
		} else switch ((n !== void 0 || o.has(void 0)) && s(o.get(n)), a && s(o.get(Ze)), t) {
			case "add":
				i ? a && s(o.get("length")) : (s(o.get(Ye)), f(e) && s(o.get(Xe)));
				break;
			case "delete":
				i || (s(o.get(Ye)), f(e) && s(o.get(Xe)));
				break;
			case "set": f(e) && s(o.get(Ye));
		}
	}
	Ne();
}
function $e(e) {
	let t = /* @__PURE__ */ L(e);
	return t === e ? t : (P(t, "iterate", Ze), /* @__PURE__ */ I(e) ? t : t.map(R));
}
function et(e) {
	return P(e = /* @__PURE__ */ L(e), "iterate", Ze), e;
}
function F(e, t) {
	return /* @__PURE__ */ It(e) ? zt(/* @__PURE__ */ Ft(e) ? R(t) : t) : R(t);
}
var tt = {
	__proto__: null,
	[Symbol.iterator]() {
		return nt(this, Symbol.iterator, (e) => F(this, e));
	},
	concat(...e) {
		return $e(this).concat(...e.map((e) => d(e) ? $e(e) : e));
	},
	entries() {
		return nt(this, "entries", (e) => (e[1] = F(this, e[1]), e));
	},
	every(e, t) {
		return it(this, "every", e, t, void 0, arguments);
	},
	filter(e, t) {
		return it(this, "filter", e, t, (e) => e.map((e) => F(this, e)), arguments);
	},
	find(e, t) {
		return it(this, "find", e, t, (e) => F(this, e), arguments);
	},
	findIndex(e, t) {
		return it(this, "findIndex", e, t, void 0, arguments);
	},
	findLast(e, t) {
		return it(this, "findLast", e, t, (e) => F(this, e), arguments);
	},
	findLastIndex(e, t) {
		return it(this, "findLastIndex", e, t, void 0, arguments);
	},
	forEach(e, t) {
		return it(this, "forEach", e, t, void 0, arguments);
	},
	includes(...e) {
		return ot(this, "includes", e);
	},
	indexOf(...e) {
		return ot(this, "indexOf", e);
	},
	join(e) {
		return $e(this).join(e);
	},
	lastIndexOf(...e) {
		return ot(this, "lastIndexOf", e);
	},
	map(e, t) {
		return it(this, "map", e, t, void 0, arguments);
	},
	pop() {
		return st(this, "pop");
	},
	push(...e) {
		return st(this, "push", e);
	},
	reduce(e, ...t) {
		return at(this, "reduce", e, t);
	},
	reduceRight(e, ...t) {
		return at(this, "reduceRight", e, t);
	},
	shift() {
		return st(this, "shift");
	},
	some(e, t) {
		return it(this, "some", e, t, void 0, arguments);
	},
	splice(...e) {
		return st(this, "splice", e);
	},
	toReversed() {
		return $e(this).toReversed();
	},
	toSorted(e) {
		return $e(this).toSorted(e);
	},
	toSpliced(...e) {
		return $e(this).toSpliced(...e);
	},
	unshift(...e) {
		return st(this, "unshift", e);
	},
	values() {
		return nt(this, "values", (e) => F(this, e));
	}
};
function nt(e, t, n) {
	let r = et(e), i = r[t]();
	return r !== e && !/* @__PURE__ */ I(e) && (i._next = i.next, i.next = () => {
		let e = i._next();
		return e.done || (e.value = n(e.value)), e;
	}), i;
}
var rt = Array.prototype;
function it(e, t, n, r, i, a) {
	let o = et(e), s = o !== e && !/* @__PURE__ */ I(e), c = o[t];
	if (c !== rt[t]) {
		let t = c.apply(e, a);
		return s ? R(t) : t;
	}
	let l = n;
	o !== e && (s ? l = function(t, r) {
		return n.call(this, F(e, t), r, e);
	} : n.length > 2 && (l = function(t, r) {
		return n.call(this, t, r, e);
	}));
	let u = c.call(o, l, r);
	return s && i ? i(u) : u;
}
function at(e, t, n, r) {
	let i = et(e), a = i !== e && !/* @__PURE__ */ I(e), o = n, s = !1;
	i !== e && (a ? (s = r.length === 0, o = function(t, r, i) {
		return s && (s = !1, t = F(e, t)), n.call(this, t, F(e, r), i, e);
	}) : n.length > 3 && (o = function(t, r, i) {
		return n.call(this, t, r, i, e);
	}));
	let c = i[t](o, ...r);
	return s ? F(e, c) : c;
}
function ot(e, t, n) {
	let r = /* @__PURE__ */ L(e);
	P(r, "iterate", Ze);
	let i = r[t](...n);
	return (i === -1 || i === !1) && /* @__PURE__ */ Lt(n[0]) ? (n[0] = /* @__PURE__ */ L(n[0]), r[t](...n)) : i;
}
function st(e, t, n = []) {
	Ve(), Me();
	let r = (/* @__PURE__ */ L(e))[t].apply(e, n);
	return Ne(), He(), r;
}
var ct = /* @__PURE__ */ e("__proto__,__v_isRef,__isVue"), lt = new Set(/* @__PURE__ */ Object.getOwnPropertyNames(Symbol).filter((e) => e !== "arguments" && e !== "caller").map((e) => Symbol[e]).filter(_));
function ut(e) {
	_(e) || (e = String(e));
	let t = /* @__PURE__ */ L(this);
	return P(t, "has", e), t.hasOwnProperty(e);
}
var dt = class {
	constructor(e = !1, t = !1) {
		this._isReadonly = e, this._isShallow = t;
	}
	get(e, t, n) {
		if (t === "__v_skip") return e.__v_skip;
		let r = this._isReadonly, i = this._isShallow;
		if (t === "__v_isReactive") return !r;
		if (t === "__v_isReadonly") return r;
		if (t === "__v_isShallow") return i;
		if (t === "__v_raw") return n === (r ? i ? kt : Ot : i ? Dt : Et).get(e) || Object.getPrototypeOf(e) === Object.getPrototypeOf(n) ? e : void 0;
		let a = d(e);
		if (!r) {
			let e;
			if (a && (e = tt[t])) return e;
			if (t === "hasOwnProperty") return ut;
		}
		let o = Reflect.get(e, t, /* @__PURE__ */ z(e) ? e : n);
		if ((_(t) ? lt.has(t) : ct(t)) || (r || P(e, "get", t), i)) return o;
		if (/* @__PURE__ */ z(o)) {
			let e = a && w(t) ? o : o.value;
			return r && v(e) ? /* @__PURE__ */ Nt(e) : e;
		}
		return v(o) ? r ? /* @__PURE__ */ Nt(o) : /* @__PURE__ */ jt(o) : o;
	}
}, ft = class extends dt {
	constructor(e = !1) {
		super(!1, e);
	}
	set(e, t, n, r) {
		let i = e[t], a = d(e) && w(t);
		if (!this._isShallow) {
			let e = /* @__PURE__ */ It(i);
			if (!/* @__PURE__ */ I(n) && !/* @__PURE__ */ It(n) && (i = /* @__PURE__ */ L(i), n = /* @__PURE__ */ L(n)), !a && /* @__PURE__ */ z(i) && !/* @__PURE__ */ z(n)) return e || (i.value = n), !0;
		}
		let o = a ? Number(t) < e.length : u(e, t), s = Reflect.set(e, t, n, /* @__PURE__ */ z(e) ? e : r);
		return e === /* @__PURE__ */ L(r) && s && (o ? D(n, i) && Qe(e, "set", t, n, i) : Qe(e, "add", t, n)), s;
	}
	deleteProperty(e, t) {
		let n = u(e, t), r = e[t], i = Reflect.deleteProperty(e, t);
		return i && n && Qe(e, "delete", t, void 0, r), i;
	}
	has(e, t) {
		let n = Reflect.has(e, t);
		return (!_(t) || !lt.has(t)) && P(e, "has", t), n;
	}
	ownKeys(e) {
		return P(e, "iterate", d(e) ? "length" : Ye), Reflect.ownKeys(e);
	}
}, pt = class extends dt {
	constructor(e = !1) {
		super(!0, e);
	}
	set(e, t) {
		return !0;
	}
	deleteProperty(e, t) {
		return !0;
	}
}, mt = /* @__PURE__ */ new ft(), ht = /* @__PURE__ */ new pt(), gt = /* @__PURE__ */ new ft(!0), _t = (e) => e, vt = (e) => Reflect.getPrototypeOf(e);
function yt(e, t, n) {
	return function(...r) {
		let i = this.__v_raw, a = /* @__PURE__ */ L(i), o = f(a), c = e === "entries" || e === Symbol.iterator && o, l = e === "keys" && o, u = i[e](...r), d = n ? _t : t ? zt : R;
		return !t && P(a, "iterate", l ? Xe : Ye), s(Object.create(u), { next() {
			let { value: e, done: t } = u.next();
			return t ? {
				value: e,
				done: t
			} : {
				value: c ? [d(e[0]), d(e[1])] : d(e),
				done: t
			};
		} });
	};
}
function bt(e) {
	return function(...t) {
		return e === "delete" ? !1 : e === "clear" ? void 0 : this;
	};
}
function xt(e, t) {
	let n = {
		get(n) {
			let r = this.__v_raw, i = /* @__PURE__ */ L(r), a = /* @__PURE__ */ L(n);
			e || (D(n, a) && P(i, "get", n), P(i, "get", a));
			let { has: o } = vt(i), s = t ? _t : e ? zt : R;
			if (o.call(i, n)) return s(r.get(n));
			if (o.call(i, a)) return s(r.get(a));
			r !== i && r.get(n);
		},
		get size() {
			let t = this.__v_raw;
			return !e && P(/* @__PURE__ */ L(t), "iterate", Ye), t.size;
		},
		has(t) {
			let n = this.__v_raw, r = /* @__PURE__ */ L(n), i = /* @__PURE__ */ L(t);
			return e || (D(t, i) && P(r, "has", t), P(r, "has", i)), t === i ? n.has(t) : n.has(t) || n.has(i);
		},
		forEach(n, r) {
			let i = this, a = i.__v_raw, o = /* @__PURE__ */ L(a), s = t ? _t : e ? zt : R;
			return !e && P(o, "iterate", Ye), a.forEach((e, t) => n.call(r, s(e), s(t), i));
		}
	};
	return s(n, e ? {
		add: bt("add"),
		set: bt("set"),
		delete: bt("delete"),
		clear: bt("clear")
	} : {
		add(e) {
			let n = /* @__PURE__ */ L(this), r = vt(n), i = /* @__PURE__ */ L(e), a = !t && !/* @__PURE__ */ I(e) && !/* @__PURE__ */ It(e) ? i : e;
			return r.has.call(n, a) || D(e, a) && r.has.call(n, e) || D(i, a) && r.has.call(n, i) || (n.add(a), Qe(n, "add", a, a)), this;
		},
		set(e, n) {
			!t && !/* @__PURE__ */ I(n) && !/* @__PURE__ */ It(n) && (n = /* @__PURE__ */ L(n));
			let r = /* @__PURE__ */ L(this), { has: i, get: a } = vt(r), o = i.call(r, e);
			o ||= (e = /* @__PURE__ */ L(e), i.call(r, e));
			let s = a.call(r, e);
			return r.set(e, n), o ? D(n, s) && Qe(r, "set", e, n, s) : Qe(r, "add", e, n), this;
		},
		delete(e) {
			let t = /* @__PURE__ */ L(this), { has: n, get: r } = vt(t), i = n.call(t, e);
			i ||= (e = /* @__PURE__ */ L(e), n.call(t, e));
			let a = r ? r.call(t, e) : void 0, o = t.delete(e);
			return i && Qe(t, "delete", e, void 0, a), o;
		},
		clear() {
			let e = /* @__PURE__ */ L(this), t = e.size !== 0, n = e.clear();
			return t && Qe(e, "clear", void 0, void 0, void 0), n;
		}
	}), [
		"keys",
		"values",
		"entries",
		Symbol.iterator
	].forEach((r) => {
		n[r] = yt(r, e, t);
	}), n;
}
function St(e, t) {
	let n = xt(e, t);
	return (t, r, i) => r === "__v_isReactive" ? !e : r === "__v_isReadonly" ? e : r === "__v_raw" ? t : Reflect.get(u(n, r) && r in t ? n : t, r, i);
}
var Ct = { get: /* @__PURE__ */ St(!1, !1) }, wt = { get: /* @__PURE__ */ St(!1, !0) }, Tt = { get: /* @__PURE__ */ St(!0, !1) }, Et = /* @__PURE__ */ new WeakMap(), Dt = /* @__PURE__ */ new WeakMap(), Ot = /* @__PURE__ */ new WeakMap(), kt = /* @__PURE__ */ new WeakMap();
function At(e) {
	switch (e) {
		case "Object":
		case "Array": return 1;
		case "Map":
		case "Set":
		case "WeakMap":
		case "WeakSet": return 2;
		default: return 0;
	}
}
// @__NO_SIDE_EFFECTS__
function jt(e) {
	return /* @__PURE__ */ It(e) ? e : Pt(e, !1, mt, Ct, Et);
}
// @__NO_SIDE_EFFECTS__
function Mt(e) {
	return Pt(e, !1, gt, wt, Dt);
}
// @__NO_SIDE_EFFECTS__
function Nt(e) {
	return Pt(e, !0, ht, Tt, Ot);
}
function Pt(e, t, n, r, i) {
	if (!v(e) || e.__v_raw && !(t && e.__v_isReactive) || e.__v_skip || !Object.isExtensible(e)) return e;
	let a = i.get(e);
	if (a) return a;
	let o = At(S(e));
	if (o === 0) return e;
	let s = new Proxy(e, o === 2 ? r : n);
	return i.set(e, s), s;
}
// @__NO_SIDE_EFFECTS__
function Ft(e) {
	return /* @__PURE__ */ It(e) ? /* @__PURE__ */ Ft(e.__v_raw) : !!(e && e.__v_isReactive);
}
// @__NO_SIDE_EFFECTS__
function It(e) {
	return !!(e && e.__v_isReadonly);
}
// @__NO_SIDE_EFFECTS__
function I(e) {
	return !!(e && e.__v_isShallow);
}
// @__NO_SIDE_EFFECTS__
function Lt(e) {
	return e ? !!e.__v_raw : !1;
}
// @__NO_SIDE_EFFECTS__
function L(e) {
	let t = e && e.__v_raw;
	return t ? /* @__PURE__ */ L(t) : e;
}
function Rt(e) {
	return !u(e, "__v_skip") && Object.isExtensible(e) && O(e, "__v_skip", !0), e;
}
var R = (e) => v(e) ? /* @__PURE__ */ jt(e) : e, zt = (e) => v(e) ? /* @__PURE__ */ Nt(e) : e;
// @__NO_SIDE_EFFECTS__
function z(e) {
	return e ? e.__v_isRef === !0 : !1;
}
// @__NO_SIDE_EFFECTS__
function B(e) {
	return Bt(e, !1);
}
function Bt(e, t) {
	return /* @__PURE__ */ z(e) ? e : new Vt(e, t);
}
var Vt = class {
	constructor(e, t) {
		this.dep = new Ke(), this.__v_isRef = !0, this.__v_isShallow = !1, this._rawValue = t ? e : /* @__PURE__ */ L(e), this._value = t ? e : R(e), this.__v_isShallow = t;
	}
	get value() {
		return this.dep.track(), this._value;
	}
	set value(e) {
		let t = this._rawValue, n = this.__v_isShallow || /* @__PURE__ */ I(e) || /* @__PURE__ */ It(e);
		e = n ? e : /* @__PURE__ */ L(e), D(e, t) && (this._rawValue = e, this._value = n ? e : R(e), this.dep.trigger());
	}
};
function Ht(e) {
	return /* @__PURE__ */ z(e) ? e.value : e;
}
var Ut = {
	get: (e, t, n) => t === "__v_raw" ? e : Ht(Reflect.get(e, t, n)),
	set: (e, t, n, r) => {
		let i = e[t];
		return /* @__PURE__ */ z(i) && !/* @__PURE__ */ z(n) ? (i.value = n, !0) : Reflect.set(e, t, n, r);
	}
};
function Wt(e) {
	return /* @__PURE__ */ Ft(e) ? e : new Proxy(e, Ut);
}
var Gt = class {
	constructor(e, t, n) {
		this.fn = e, this.setter = t, this._value = void 0, this.dep = new Ke(this), this.__v_isRef = !0, this.deps = void 0, this.depsTail = void 0, this.flags = 16, this.globalVersion = We - 1, this.next = void 0, this.effect = this, this.__v_isReadonly = !t, this.isSSR = n;
	}
	notify() {
		if (this.flags |= 16, !(this.flags & 8) && M !== this) return je(this, !0), !0;
	}
	get value() {
		let e = this.dep.track();
		return Le(this), e && (e.version = this.dep.version), this._value;
	}
	set value(e) {
		this.setter && this.setter(e);
	}
};
// @__NO_SIDE_EFFECTS__
function Kt(e, t, n = !1) {
	let r, i;
	return h(e) ? r = e : (r = e.get, i = e.set), new Gt(r, i, n);
}
var qt = {}, Jt = /* @__PURE__ */ new WeakMap(), Yt = void 0;
function Xt(e, t = !1, n = Yt) {
	if (n) {
		let t = Jt.get(n);
		t || Jt.set(n, t = []), t.push(e);
	}
}
function Zt(e, n, i = t) {
	let { immediate: a, deep: o, once: s, scheduler: l, augmentJob: u, call: f } = i, p = (e) => o ? e : /* @__PURE__ */ I(e) || o === !1 || o === 0 ? Qt(e, 1) : Qt(e), m, g, _, v, y = !1, b = !1;
	if (/* @__PURE__ */ z(e) ? (g = () => e.value, y = /* @__PURE__ */ I(e)) : /* @__PURE__ */ Ft(e) ? (g = () => p(e), y = !0) : d(e) ? (b = !0, y = e.some((e) => /* @__PURE__ */ Ft(e) || /* @__PURE__ */ I(e)), g = () => e.map((e) => {
		if (/* @__PURE__ */ z(e)) return e.value;
		if (/* @__PURE__ */ Ft(e)) return p(e);
		if (h(e)) return f ? f(e, 2) : e();
	})) : g = h(e) ? n ? f ? () => f(e, 2) : e : () => {
		if (_) {
			Ve();
			try {
				_();
			} finally {
				He();
			}
		}
		let t = Yt;
		Yt = m;
		try {
			return f ? f(e, 3, [v]) : e(v);
		} finally {
			Yt = t;
		}
	} : r, n && o) {
		let e = g, t = o === !0 ? Infinity : o;
		g = () => Qt(e(), t);
	}
	let x = Te(), S = () => {
		m.stop(), x && x.active && c(x.effects, m);
	};
	if (s && n) {
		let e = n;
		n = (...t) => {
			let n = e(...t);
			return S(), n;
		};
	}
	let C = b ? Array(e.length).fill(qt) : qt, w = (e) => {
		if (m.flags & 1 && (m.dirty || e)) {
			if (n) {
				let t = m.run();
				if (e || o || y || (b ? t.some((e, t) => D(e, C[t])) : D(t, C))) {
					_ && _();
					let e = Yt;
					Yt = m;
					try {
						let e = [
							t,
							C === qt ? void 0 : b && C[0] === qt ? [] : C,
							v
						];
						C = t, f ? f(n, 3, e) : n(...e);
					} finally {
						Yt = e;
					}
				}
			} else m.run();
		}
	};
	return u && u(w), m = new De(g), m.scheduler = l ? () => l(w, !1) : w, v = (e) => Xt(e, !1, m), _ = m.onStop = () => {
		let e = Jt.get(m);
		if (e) {
			if (f) f(e, 4);
			else for (let t of e) t();
			Jt.delete(m);
		}
	}, n ? a ? w(!0) : C = m.run() : l ? l(w.bind(null, !0), !0) : m.run(), S.pause = m.pause.bind(m), S.resume = m.resume.bind(m), S.stop = S, S;
}
function Qt(e, t = Infinity, n) {
	if (t <= 0 || !v(e) || e.__v_skip || (n ||= /* @__PURE__ */ new Map(), (n.get(e) || 0) >= t)) return e;
	if (n.set(e, t), t--, /* @__PURE__ */ z(e)) Qt(e.value, t, n);
	else if (d(e)) for (let r = 0; r < e.length; r++) Qt(e[r], t, n);
	else if (p(e) || f(e)) e.forEach((e) => {
		Qt(e, t, n);
	});
	else if (C(e)) {
		for (let r in e) Qt(e[r], t, n);
		for (let r of Object.getOwnPropertySymbols(e)) Object.prototype.propertyIsEnumerable.call(e, r) && Qt(e[r], t, n);
	}
	return e;
}
//#endregion
//#region ../../../../node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
function $t(e, t, n, r) {
	try {
		return r ? e(...r) : e();
	} catch (e) {
		en(e, t, n);
	}
}
function V(e, t, n, r) {
	if (h(e)) {
		let i = $t(e, t, n, r);
		return i && y(i) && i.catch((e) => {
			en(e, t, n);
		}), i;
	}
	if (d(e)) {
		let i = [];
		for (let a = 0; a < e.length; a++) i.push(V(e[a], t, n, r));
		return i;
	}
}
function en(e, n, r, i = !0) {
	let a = n ? n.vnode : null, { errorHandler: o, throwUnhandledErrorInProduction: s } = n && n.appContext.config || t;
	if (n) {
		let t = n.parent, i = n.proxy, a = `https://vuejs.org/error-reference/#runtime-${r}`;
		for (; t;) {
			let n = t.ec;
			if (n) {
				for (let t = 0; t < n.length; t++) if (n[t](e, i, a) === !1) return;
			}
			t = t.parent;
		}
		if (o) {
			Ve(), $t(o, null, 10, [
				e,
				i,
				a
			]), He();
			return;
		}
	}
	tn(e, r, a, i, s);
}
function tn(e, t, n, r = !0, i = !1) {
	if (i) throw e;
	console.error(e);
}
var H = [], U = -1, nn = [], rn = null, an = 0, on = /* @__PURE__ */ Promise.resolve(), sn = null;
function cn(e) {
	let t = sn || on;
	return e ? t.then(this ? e.bind(this) : e) : t;
}
function ln(e) {
	let t = U + 1, n = H.length;
	for (; t < n;) {
		let r = t + n >>> 1, i = H[r], a = hn(i);
		a < e || a === e && i.flags & 2 ? t = r + 1 : n = r;
	}
	return t;
}
function un(e) {
	if (!(e.flags & 1)) {
		let t = hn(e), n = H[H.length - 1];
		!n || !(e.flags & 2) && t >= hn(n) ? H.push(e) : H.splice(ln(t), 0, e), e.flags |= 1, dn();
	}
}
function dn() {
	sn ||= on.then(gn);
}
function fn(e) {
	if (!d(e)) rn && e.id === -1 ? rn.splice(an + 1, 0, e) : e.flags & 1 || (nn.push(e), e.flags |= 1);
	else for (let t = 0; t < e.length; t++) nn.push(e[t]);
	dn();
}
function pn(e, t, n = U + 1) {
	for (; n < H.length; n++) {
		let t = H[n];
		if (t && t.flags & 2) {
			if (e && t.id !== e.uid) continue;
			H.splice(n, 1), n--, t.flags & 4 && (t.flags &= -2), t(), t.flags & 4 || (t.flags &= -2);
		}
	}
}
function mn(e) {
	if (nn.length) {
		let e = [...new Set(nn)].sort((e, t) => hn(e) - hn(t));
		if (nn.length = 0, rn) {
			for (let t = 0; t < e.length; t++) rn.push(e[t]);
			return;
		}
		for (rn = e, an = 0; an < rn.length; an++) {
			let e = rn[an];
			e.flags & 4 && (e.flags &= -2), e.flags & 8 || e(), e.flags &= -2;
		}
		rn = null, an = 0;
	}
}
var hn = (e) => e.id == null ? e.flags & 2 ? -1 : Infinity : e.id;
function gn(e) {
	try {
		for (U = 0; U < H.length; U++) {
			let e = H[U];
			e && !(e.flags & 8) && (e.flags & 4 && (e.flags &= -2), $t(e, e.i, e.i ? 15 : 14), e.flags & 4 || (e.flags &= -2));
		}
	} finally {
		for (; U < H.length; U++) {
			let e = H[U];
			e && (e.flags &= -2);
		}
		U = -1, H.length = 0, mn(e), sn = null, (H.length || nn.length) && gn(e);
	}
}
var _n = null, vn = null;
function yn(e) {
	let t = _n;
	return _n = e, vn = e && e.type.__scopeId || null, t;
}
function bn(e, t = _n, n) {
	if (!t || e._n) return e;
	let r = (...n) => {
		r._d && Ti(-1);
		let i = yn(t), a = Si.length, o;
		try {
			o = e(...n);
		} finally {
			for (let e = Si.length; e > a; e--) Ci();
			yn(i), r._d && Ti(1);
		}
		return o;
	};
	return r._n = !0, r._c = !0, r._d = !0, r;
}
function xn(e, t, n, r) {
	let i = e.dirs, a = t && t.dirs;
	for (let o = 0; o < i.length; o++) {
		let s = i[o];
		a && (s.oldValue = a[o].value);
		let c = s.dir[r];
		c && (Ve(), V(c, n, 8, [
			e.el,
			s,
			e,
			t
		]), He());
	}
}
function Sn(e, t) {
	if ($) {
		let n = $.provides, r = $.parent && $.parent.provides;
		r === n && (n = $.provides = Object.create(r)), n[e] = t;
	}
}
function Cn(e, t, n = !1) {
	let r = Wi();
	if (r || Ar) {
		let i = Ar ? Ar._context.provides : r ? r.parent == null || r.ce ? r.vnode.appContext && r.vnode.appContext.provides : r.parent.provides : void 0;
		if (i && e in i) return i[e];
		if (arguments.length > 1) return n && h(t) ? t.call(r && r.proxy) : t;
	}
}
var wn = /* @__PURE__ */ Symbol.for("v-scx"), Tn = () => Cn(wn);
function En(e, t, n) {
	return Dn(e, t, n);
}
function Dn(e, n, i = t) {
	let { immediate: a, deep: o, flush: c, once: l } = i, u = s({}, i), d = n && a || !n && c !== "post", f;
	if (Xi) {
		if (c === "sync") {
			let e = Tn();
			f = e.__watcherHandles ||= [];
		} else if (!d) {
			let e = () => {};
			return e.stop = r, e.resume = r, e.pause = r, e;
		}
	}
	let p = $;
	u.call = (e, t, n) => V(e, p, t, n);
	let m = !1;
	c === "post" ? u.scheduler = (e) => {
		G(e, p && p.suspense);
	} : c !== "sync" && (m = !0, u.scheduler = (e, t) => {
		t ? e() : un(e);
	}), u.augmentJob = (e) => {
		n && (e.flags |= 4), m && (e.flags |= 2, p && (e.id = p.uid, e.i = p));
	};
	let h = Zt(e, n, u);
	return Xi && (f ? f.push(h) : d && h()), h;
}
function On(e, t, n) {
	let r = this.proxy, i = g(e) ? e.includes(".") ? kn(r, e) : () => r[e] : e.bind(r, r), a;
	h(t) ? a = t : (a = t.handler, n = t);
	let o = qi(this), s = Dn(i, a.bind(r), n);
	return o(), s;
}
function kn(e, t) {
	let n = t.split(".");
	return () => {
		let t = e;
		for (let e = 0; e < n.length && t; e++) t = t[n[e]];
		return t;
	};
}
var An = /* @__PURE__ */ Symbol("_vte"), jn = (e) => e.__isTeleport, Mn = /* @__PURE__ */ Symbol("_leaveCb");
function Nn(e) {
	let t = e[0];
	if (e.length > 1) {
		for (let n of e) if (n.type !== bi) {
			t = n;
			break;
		}
	}
	return t;
}
function Pn(e) {
	if (!Un(e)) return jn(e.type) && e.children ? Nn(e.children) : e;
	if (e.component) return e.component.subTree;
	let { shapeFlag: t, children: n } = e;
	if (n) {
		if (t & 16) return n[0];
		if (t & 32 && h(n.default)) return n.default();
	}
}
function Fn(e, t) {
	if (e.shapeFlag & 6 && e.component) {
		e.transition = t;
		let n = e.component.subTree;
		Fn(jn(n.type) && Pn(n) || n, t);
	} else e.shapeFlag & 128 ? (e.ssContent.transition = t.clone(e.ssContent), e.ssFallback.transition = t.clone(e.ssFallback)) : e.transition = t;
}
// @__NO_SIDE_EFFECTS__
function In(e, t) {
	return h(e) ? /* @__PURE__ */ s({ name: e.name }, t, { setup: e }) : e;
}
function Ln(e) {
	e.ids = [
		e.ids[0] + e.ids[2]++ + "-",
		0,
		0
	];
}
function Rn(e, t) {
	let n;
	return !!((n = Object.getOwnPropertyDescriptor(e, t)) && !n.configurable);
}
var zn = /* @__PURE__ */ new WeakMap();
function Bn(e, n, r, a, o = !1) {
	if (d(e)) {
		e.forEach((e, t) => Bn(e, n && (d(n) ? n[t] : n), r, a, o));
		return;
	}
	if (Hn(a) && !o) {
		a.shapeFlag & 512 && a.type.__asyncResolved && a.component.subTree.component && Bn(e, n, r, a.component.subTree);
		return;
	}
	let s = a.shapeFlag & 4 ? ra(a.component) : a.el, l = o ? null : s, { i: f, r: p } = e, m = n && n.r, _ = f.refs === t ? f.refs = {} : f.refs, v = f.setupState, y = /* @__PURE__ */ L(v), b = v === t ? i : (e) => !Rn(_, e) && u(y, e), x = (e, t) => !(t && Rn(_, t));
	if (m != null && m !== p) {
		if (Vn(n), g(m)) _[m] = null, b(m) && (v[m] = null);
		else if (/* @__PURE__ */ z(m)) {
			let e = n;
			x(m, e.k) && (m.value = null), e.k && (_[e.k] = null);
		}
	}
	if (h(p)) $t(p, f, 12, [l, _]);
	else {
		let t = g(p), n = /* @__PURE__ */ z(p);
		if (t || n) {
			let i = () => {
				if (e.f) {
					let n = t ? b(p) ? v[p] : _[p] : x(p) || !e.k ? p.value : _[e.k];
					if (o) d(n) && c(n, s);
					else if (d(n)) n.includes(s) || n.push(s);
					else if (t) _[p] = [s], b(p) && (v[p] = _[p]);
					else {
						let t = [s];
						x(p, e.k) && (p.value = t), e.k && (_[e.k] = t);
					}
				} else t ? (_[p] = l, b(p) && (v[p] = l)) : n && (x(p, e.k) && (p.value = l), e.k && (_[e.k] = l));
			};
			if (l) {
				let t = () => {
					i(), zn.delete(e);
				};
				t.id = -1, zn.set(e, t), G(t, r);
			} else Vn(e), i();
		}
	}
}
function Vn(e) {
	let t = zn.get(e);
	t && (t.flags |= 8, zn.delete(e));
}
le().requestIdleCallback, le().cancelIdleCallback;
var Hn = (e) => !!e.type.__asyncLoader, Un = (e) => e.type.__isKeepAlive;
function Wn(e, t) {
	Kn(e, "a", t);
}
function Gn(e, t) {
	Kn(e, "da", t);
}
function Kn(e, t, n = $) {
	let r = e.__wdc ||= () => {
		let t = n;
		for (; t;) {
			if (t.isDeactivated) return;
			t = t.parent;
		}
		return e();
	};
	if (Jn(t, r, n), n) {
		let e = n.parent;
		for (; e && e.parent;) Un(e.parent.vnode) && qn(r, t, n, e), e = e.parent;
	}
}
function qn(e, t, n, r) {
	let i = Jn(t, e, r, !0);
	tr(() => {
		c(r[t], i);
	}, n);
}
function Jn(e, t, n = $, r = !1) {
	if (n) {
		let i = n[e] || (n[e] = []), a = t.__weh ||= (...r) => {
			Ve();
			let i = qi(n), a = V(t, n, e, r);
			return i(), He(), a;
		};
		return r ? i.unshift(a) : i.push(a), a;
	}
}
var Yn = (e) => (t, n = $) => {
	(!Xi || e === "sp") && Jn(e, (...e) => t(...e), n);
}, Xn = Yn("bm"), Zn = Yn("m"), Qn = Yn("bu"), $n = Yn("u"), er = Yn("bum"), tr = Yn("um"), nr = Yn("sp"), rr = Yn("rtg"), ir = Yn("rtc");
function ar(e, t = $) {
	Jn("ec", e, t);
}
var or = /* @__PURE__ */ Symbol.for("v-ndc");
function sr(e, t, n, r) {
	let i, a = n && n[r], o = d(e);
	if (o || g(e)) {
		let n = o && /* @__PURE__ */ Ft(e), r = !1, s = !1;
		n && (r = !/* @__PURE__ */ I(e), s = /* @__PURE__ */ It(e), e = et(e)), i = Array(e.length);
		for (let n = 0, o = e.length; n < o; n++) i[n] = t(r ? s ? zt(R(e[n])) : R(e[n]) : e[n], n, void 0, a && a[n]);
	} else if (typeof e == "number") {
		i = Array(e);
		for (let n = 0; n < e; n++) i[n] = t(n + 1, n, void 0, a && a[n]);
	} else if (v(e)) {
		if (e[Symbol.iterator]) i = Array.from(e, (e, n) => t(e, n, void 0, a && a[n]));
		else {
			let n = Object.keys(e);
			i = Array(n.length);
			for (let r = 0, o = n.length; r < o; r++) {
				let o = n[r];
				i[r] = t(e[o], o, r, a && a[r]);
			}
		}
	} else i = [];
	return n && (n[r] = i), i;
}
var cr = (e) => e ? Yi(e) ? ra(e) : cr(e.parent) : null, lr = /* @__PURE__ */ s(/* @__PURE__ */ Object.create(null), {
	$: (e) => e,
	$el: (e) => e.vnode.el,
	$data: (e) => e.data,
	$props: (e) => e.props,
	$attrs: (e) => e.attrs,
	$slots: (e) => e.slots,
	$refs: (e) => e.refs,
	$parent: (e) => cr(e.parent),
	$root: (e) => cr(e.root),
	$host: (e) => e.ce,
	$emit: (e) => e.emit,
	$options: (e) => vr(e),
	$forceUpdate: (e) => e.f ||= () => {
		un(e.update);
	},
	$nextTick: (e) => e.n ||= cn.bind(e.proxy),
	$watch: (e) => On.bind(e)
}), ur = (e, n) => e !== t && !e.__isScriptSetup && u(e, n), dr = {
	get({ _: e }, n) {
		if (n === "__v_skip") return !0;
		let { ctx: r, setupState: i, data: a, props: o, accessCache: s, type: c, appContext: l } = e;
		if (n[0] !== "$") {
			let e = s[n];
			if (e !== void 0) switch (e) {
				case 1: return i[n];
				case 2: return a[n];
				case 4: return r[n];
				case 3: return o[n];
			}
			else if (ur(i, n)) return s[n] = 1, i[n];
			else if (a !== t && u(a, n)) return s[n] = 2, a[n];
			else if (u(o, n)) return s[n] = 3, o[n];
			else if (r !== t && u(r, n)) return s[n] = 4, r[n];
			else pr && (s[n] = 0);
		}
		let d = lr[n], f, p;
		if (d) return n === "$attrs" && P(e.attrs, "get", ""), d(e);
		if ((f = c.__cssModules) && (f = f[n])) return f;
		if (r !== t && u(r, n)) return s[n] = 4, r[n];
		if (p = l.config.globalProperties, u(p, n)) return p[n];
	},
	set({ _: e }, n, r) {
		let { data: i, setupState: a, ctx: o } = e;
		return ur(a, n) ? (a[n] = r, !0) : i !== t && u(i, n) ? (i[n] = r, !0) : u(e.props, n) || n[0] === "$" && n.slice(1) in e ? !1 : (o[n] = r, !0);
	},
	has({ _: { data: e, setupState: n, accessCache: r, ctx: i, appContext: a, props: o, type: s } }, c) {
		let l;
		return !!(r[c] || e !== t && c[0] !== "$" && u(e, c) || ur(n, c) || u(o, c) || u(i, c) || u(lr, c) || u(a.config.globalProperties, c) || (l = s.__cssModules) && l[c]);
	},
	defineProperty(e, t, n) {
		return n.get == null ? u(n, "value") && this.set(e, t, n.value, null) : e._.accessCache[t] = 0, Reflect.defineProperty(e, t, n);
	}
};
function fr(e) {
	return d(e) ? e.reduce((e, t) => (e[t] = null, e), {}) : e;
}
var pr = !0;
function mr(e) {
	let t = vr(e), n = e.proxy, i = e.ctx;
	pr = !1, t.beforeCreate && gr(t.beforeCreate, e, "bc");
	let { data: a, computed: o, methods: s, watch: c, provide: l, inject: u, created: f, beforeMount: p, mounted: m, beforeUpdate: g, updated: _, activated: y, deactivated: b, beforeDestroy: x, beforeUnmount: S, destroyed: C, unmounted: w, render: ee, renderTracked: te, renderTriggered: ne, errorCaptured: T, serverPrefetch: re, expose: E, inheritAttrs: ie, components: ae, directives: D, filters: oe } = t;
	if (u && hr(u, i, null), s) for (let e in s) {
		let t = s[e];
		h(t) && (i[e] = t.bind(n));
	}
	if (a) {
		let t = a.call(n, n);
		v(t) && (e.data = /* @__PURE__ */ jt(t));
	}
	if (pr = !0, o) for (let e in o) {
		let t = o[e], a = aa({
			get: h(t) ? t.bind(n, n) : h(t.get) ? t.get.bind(n, n) : r,
			set: !h(t) && h(t.set) ? t.set.bind(n) : r
		});
		Object.defineProperty(i, e, {
			enumerable: !0,
			configurable: !0,
			get: () => a.value,
			set: (e) => a.value = e
		});
	}
	if (c) for (let e in c) _r(c[e], i, n, e);
	if (l) {
		let e = h(l) ? l.call(n) : l;
		Reflect.ownKeys(e).forEach((t) => {
			Sn(t, e[t]);
		});
	}
	f && gr(f, e, "c");
	function O(e, t) {
		d(t) ? t.forEach((t) => e(t.bind(n))) : t && e(t.bind(n));
	}
	if (O(Xn, p), O(Zn, m), O(Qn, g), O($n, _), O(Wn, y), O(Gn, b), O(ar, T), O(ir, te), O(rr, ne), O(er, S), O(tr, w), O(nr, re), d(E)) {
		if (E.length) {
			let t = e.exposed ||= {};
			E.forEach((e) => {
				Object.defineProperty(t, e, {
					get: () => n[e],
					set: (t) => n[e] = t,
					enumerable: !0
				});
			});
		} else e.exposed ||= {};
	}
	ee && e.render === r && (e.render = ee), ie != null && (e.inheritAttrs = ie), ae && (e.components = ae), D && (e.directives = D), re && Ln(e);
}
function hr(e, t, n = r) {
	d(e) && (e = Cr(e));
	for (let n in e) {
		let r = e[n], i;
		i = v(r) ? "default" in r ? Cn(r.from || n, r.default, !0) : Cn(r.from || n) : Cn(r), /* @__PURE__ */ z(i) ? Object.defineProperty(t, n, {
			enumerable: !0,
			configurable: !0,
			get: () => i.value,
			set: (e) => i.value = e
		}) : t[n] = i;
	}
}
function gr(e, t, n) {
	V(d(e) ? e.map((e) => e.bind(t.proxy)) : e.bind(t.proxy), t, n);
}
function _r(e, t, n, r) {
	let i = r.includes(".") ? kn(n, r) : () => n[r];
	if (g(e)) {
		let n = t[e];
		h(n) && En(i, n);
	} else if (h(e)) En(i, e.bind(n));
	else if (v(e)) {
		if (d(e)) e.forEach((e) => _r(e, t, n, r));
		else {
			let r = h(e.handler) ? e.handler.bind(n) : t[e.handler];
			h(r) && En(i, r, e);
		}
	}
}
function vr(e) {
	let t = e.type, { mixins: n, extends: r } = t, { mixins: i, optionsCache: a, config: { optionMergeStrategies: o } } = e.appContext, s = a.get(t), c;
	return s ? c = s : !i.length && !n && !r ? c = t : (c = {}, i.length && i.forEach((e) => yr(c, e, o, !0)), yr(c, t, o)), v(t) && a.set(t, c), c;
}
function yr(e, t, n, r = !1) {
	let { mixins: i, extends: a } = t;
	a && yr(e, a, n, !0), i && i.forEach((t) => yr(e, t, n, !0));
	for (let i in t) if (!(r && i === "expose")) {
		let r = br[i] || n && n[i];
		e[i] = r ? r(e[i], t[i]) : t[i];
	}
	return e;
}
var br = {
	data: xr,
	props: Tr,
	emits: Tr,
	methods: wr,
	computed: wr,
	beforeCreate: W,
	created: W,
	beforeMount: W,
	mounted: W,
	beforeUpdate: W,
	updated: W,
	beforeDestroy: W,
	beforeUnmount: W,
	destroyed: W,
	unmounted: W,
	activated: W,
	deactivated: W,
	errorCaptured: W,
	serverPrefetch: W,
	components: wr,
	directives: wr,
	watch: Er,
	provide: xr,
	inject: Sr
};
function xr(e, t) {
	return t ? e ? function() {
		return s(h(e) ? e.call(this, this) : e, h(t) ? t.call(this, this) : t);
	} : t : e;
}
function Sr(e, t) {
	return wr(Cr(e), Cr(t));
}
function Cr(e) {
	if (d(e)) {
		let t = {};
		for (let n = 0; n < e.length; n++) t[e[n]] = e[n];
		return t;
	}
	return e;
}
function W(e, t) {
	return e ? [...new Set([].concat(e, t))] : t;
}
function wr(e, t) {
	return e ? s(/* @__PURE__ */ Object.create(null), e, t) : t;
}
function Tr(e, t) {
	return e ? d(e) && d(t) ? [.../* @__PURE__ */ new Set([...e, ...t])] : s(/* @__PURE__ */ Object.create(null), fr(e), fr(t ?? {})) : t;
}
function Er(e, t) {
	if (!e) return t;
	if (!t) return e;
	let n = s(/* @__PURE__ */ Object.create(null), e);
	for (let r in t) n[r] = W(e[r], t[r]);
	return n;
}
function Dr() {
	return {
		app: null,
		config: {
			isNativeTag: i,
			performance: !1,
			globalProperties: {},
			optionMergeStrategies: {},
			errorHandler: void 0,
			warnHandler: void 0,
			compilerOptions: {}
		},
		mixins: [],
		components: {},
		directives: {},
		provides: /* @__PURE__ */ Object.create(null),
		optionsCache: /* @__PURE__ */ new WeakMap(),
		propsCache: /* @__PURE__ */ new WeakMap(),
		emitsCache: /* @__PURE__ */ new WeakMap()
	};
}
var Or = 0;
function kr(e, t) {
	return function(n, r = null) {
		h(n) || (n = s({}, n)), r != null && !v(r) && (r = null);
		let i = Dr(), a = /* @__PURE__ */ new WeakSet(), o = [], c = !1, l = i.app = {
			_uid: Or++,
			_component: n,
			_props: r,
			_container: null,
			_context: i,
			_instance: null,
			version: oa,
			get config() {
				return i.config;
			},
			set config(e) {},
			use(e, ...t) {
				return a.has(e) || (e && h(e.install) ? (a.add(e), e.install(l, ...t)) : h(e) && (a.add(e), e(l, ...t))), l;
			},
			mixin(e) {
				return i.mixins.includes(e) || i.mixins.push(e), l;
			},
			component(e, t) {
				return t ? (i.components[e] = t, l) : i.components[e];
			},
			directive(e, t) {
				return t ? (i.directives[e] = t, l) : i.directives[e];
			},
			mount(a, o, s) {
				if (!c) {
					let u = l._ceVNode || Mi(n, r);
					return u.appContext = i, s === !0 ? s = "svg" : s === !1 && (s = void 0), o && t ? t(u, a) : e(u, a, s), c = !0, l._container = a, a.__vue_app__ = l, ra(u.component);
				}
			},
			onUnmount(e) {
				o.push(e);
			},
			unmount() {
				c && (V(o, l._instance, 16), e(null, l._container), delete l._container.__vue_app__);
			},
			provide(e, t) {
				return i.provides[e] = t, l;
			},
			runWithContext(e) {
				let t = Ar;
				Ar = l;
				try {
					return e();
				} finally {
					Ar = t;
				}
			}
		};
		return l;
	};
}
var Ar = null, jr = (e, t) => t === "modelValue" || t === "model-value" ? e.modelModifiers : e[`${t}Modifiers`] || e[`${T(t)}Modifiers`] || e[`${E(t)}Modifiers`];
function Mr(e, n, ...r) {
	if (e.isUnmounted) return;
	let i = e.vnode.props || t, a = r, o = n.startsWith("update:"), s = o && jr(i, n.slice(7));
	s && (s.trim && (a = r.map((e) => g(e) ? e.trim() : e)), s.number && (a = a.map(se)));
	let c, l = i[c = ae(n)] || i[c = ae(T(n))];
	!l && o && (l = i[c = ae(E(n))]), l && V(l, e, 6, a);
	let u = i[c + "Once"];
	if (u) {
		if (!e.emitted) e.emitted = {};
		else if (e.emitted[c]) return;
		e.emitted[c] = !0, V(u, e, 6, a);
	}
}
var Nr = /* @__PURE__ */ new WeakMap();
function Pr(e, t, n = !1) {
	let r = n ? Nr : t.emitsCache, i = r.get(e);
	if (i !== void 0) return i;
	let a = e.emits, o = {}, c = !1;
	if (!h(e)) {
		let r = (e) => {
			let n = Pr(e, t, !0);
			n && (c = !0, s(o, n));
		};
		!n && t.mixins.length && t.mixins.forEach(r), e.extends && r(e.extends), e.mixins && e.mixins.forEach(r);
	}
	return !a && !c ? (v(e) && r.set(e, null), null) : (d(a) ? a.forEach((e) => o[e] = null) : s(o, a), v(e) && r.set(e, o), o);
}
function Fr(e, t) {
	return !e || !a(t) ? !1 : (t = t.slice(2), t = t === "Once" ? t : t.replace(/Once$/, ""), u(e, t[0].toLowerCase() + t.slice(1)) || u(e, E(t)) || u(e, t));
}
function Ir(e) {
	let { type: t, vnode: n, proxy: r, withProxy: i, propsOptions: [a], slots: s, attrs: c, emit: l, render: u, renderCache: d, props: f, data: p, setupState: m, ctx: h, inheritAttrs: g } = e, _ = yn(e), v, y;
	try {
		if (n.shapeFlag & 4) {
			let e = i || r, t = e;
			v = Li(u.call(t, e, d, f, m, p, h)), y = c;
		} else {
			let e = t;
			v = Li(e.length > 1 ? e(f, {
				attrs: c,
				slots: s,
				emit: l
			}) : e(f, null)), y = t.props ? c : Lr(c);
		}
	} catch (t) {
		Si.length = 0, en(t, e, 1), v = Mi(bi);
	}
	let b = v;
	if (y && g !== !1) {
		let e = Object.keys(y), { shapeFlag: t } = b;
		e.length && t & 7 && (a && e.some(o) && (y = Rr(y, a)), b = Fi(b, y, !1, !0));
	}
	return n.dirs && (b = Fi(b, null, !1, !0), b.dirs = b.dirs ? b.dirs.concat(n.dirs) : n.dirs), n.transition && Fn(jn(b.type) && Pn(b) || b, n.transition), v = b, yn(_), v;
}
var Lr = (e) => {
	let t;
	for (let n in e) (n === "class" || n === "style" || a(n)) && ((t ||= {})[n] = e[n]);
	return t;
}, Rr = (e, t) => {
	let n = {};
	for (let r in e) (!o(r) || !(r.slice(9) in t)) && (n[r] = e[r]);
	return n;
};
function zr(e, t, n) {
	let { props: r, children: i, component: a } = e, { props: o, children: s, patchFlag: c } = t, l = a.emitsOptions;
	if (t.dirs || t.transition) return !0;
	if (n && c >= 0) {
		if (c & 1024) return !0;
		if (c & 16) return r ? Br(r, o, l) : !!o;
		if (c & 8) {
			let e = t.dynamicProps;
			for (let t = 0; t < e.length; t++) {
				let n = e[t];
				if (Vr(o, r, n) && !Fr(l, n)) return !0;
			}
		}
	} else return (i || s) && (!s || !s.$stable) ? !0 : r === o ? !1 : r ? !o || Br(r, o, l) : !!o;
	return !1;
}
function Br(e, t, n) {
	let r = Object.keys(t);
	if (r.length !== Object.keys(e).length) return !0;
	for (let i = 0; i < r.length; i++) {
		let a = r[i];
		if (Vr(t, e, a) && !Fr(n, a)) return !0;
	}
	return !1;
}
function Vr(e, t, n) {
	let r = e[n], i = t[n];
	return n === "style" && v(r) && v(i) ? !be(r, i) : r !== i;
}
function Hr({ vnode: e, parent: t, suspense: n }, r) {
	for (; t;) {
		let n = t.subTree;
		if (n.suspense && n.suspense.activeBranch === e && (n.suspense.vnode.el = n.el = r, e = n), n === e) (e = t.vnode).el = r, t = t.parent;
		else break;
	}
	n && n.activeBranch === e && (n.vnode.el = r);
}
var Ur = {}, Wr = () => Object.create(Ur), Gr = (e) => Object.getPrototypeOf(e) === Ur;
function Kr(e, t, n, r = !1) {
	let i = {}, a = Wr();
	e.propsDefaults = /* @__PURE__ */ Object.create(null), Jr(e, t, i, a);
	for (let t in e.propsOptions[0]) t in i || (i[t] = void 0);
	e.props = n ? r ? i : /* @__PURE__ */ Mt(i) : e.type.props ? i : a, e.attrs = a;
}
function qr(e, t, n, r) {
	let { props: i, attrs: a, vnode: { patchFlag: o } } = e, s = /* @__PURE__ */ L(i), [c] = e.propsOptions, l = !1;
	if ((r || o > 0) && !(o & 16)) {
		if (o & 8) {
			let n = e.vnode.dynamicProps;
			for (let r = 0; r < n.length; r++) {
				let o = n[r];
				if (Fr(e.emitsOptions, o)) continue;
				let d = t[o];
				if (c) {
					if (u(a, o)) d !== a[o] && (a[o] = d, l = !0);
					else {
						let t = T(o);
						i[t] = Yr(c, s, t, d, e, !1);
					}
				} else d !== a[o] && (a[o] = d, l = !0);
			}
		}
	} else {
		Jr(e, t, i, a) && (l = !0);
		let r;
		for (let a in s) (!t || !u(t, a) && ((r = E(a)) === a || !u(t, r))) && (c ? n && (n[a] !== void 0 || n[r] !== void 0) && (i[a] = Yr(c, s, a, void 0, e, !0)) : delete i[a]);
		if (a !== s) for (let e in a) (!t || !u(t, e)) && (delete a[e], l = !0);
	}
	l && Qe(e.attrs, "set", "");
}
function Jr(e, n, r, i) {
	let [a, o] = e.propsOptions, s = !1, c;
	if (n) for (let t in n) {
		if (ee(t)) continue;
		let l = n[t], d;
		a && u(a, d = T(t)) ? !o || !o.includes(d) ? r[d] = l : (c ||= {})[d] = l : Fr(e.emitsOptions, t) || (!(t in i) || l !== i[t]) && (i[t] = l, s = !0);
	}
	if (o) {
		let n = /* @__PURE__ */ L(r), i = c || t;
		for (let t = 0; t < o.length; t++) {
			let s = o[t];
			r[s] = Yr(a, n, s, i[s], e, !u(i, s));
		}
	}
	return s;
}
function Yr(e, t, n, r, i, a) {
	let o = e[n];
	if (o != null) {
		let e = u(o, "default");
		if (e && r === void 0) {
			let e = o.default;
			if (o.type !== Function && !o.skipFactory && h(e)) {
				let { propsDefaults: a } = i;
				if (n in a) r = a[n];
				else {
					let o = qi(i);
					r = a[n] = e.call(null, t), o();
				}
			} else r = e;
			i.ce && i.ce._setProp(n, r);
		}
		o[0] && (a && !e ? r = !1 : o[1] && (r === "" || r === E(n)) && (r = !0));
	}
	return r;
}
var Xr = /* @__PURE__ */ new WeakMap();
function Zr(e, r, i = !1) {
	let a = i ? Xr : r.propsCache, o = a.get(e);
	if (o) return o;
	let c = e.props, l = {}, f = [], p = !1;
	if (!h(e)) {
		let t = (e) => {
			p = !0;
			let [t, n] = Zr(e, r, !0);
			s(l, t), n && f.push(...n);
		};
		!i && r.mixins.length && r.mixins.forEach(t), e.extends && t(e.extends), e.mixins && e.mixins.forEach(t);
	}
	if (!c && !p) return v(e) && a.set(e, n), n;
	if (d(c)) for (let e = 0; e < c.length; e++) {
		let n = T(c[e]);
		Qr(n) && (l[n] = t);
	}
	else if (c) for (let e in c) {
		let t = T(e);
		if (Qr(t)) {
			let n = c[e], r = l[t] = d(n) || h(n) ? { type: n } : s({}, n), i = r.type, a = !1, o = !0;
			if (d(i)) for (let e = 0; e < i.length; ++e) {
				let t = i[e], n = h(t) && t.name;
				if (n === "Boolean") {
					a = !0;
					break;
				}
				n === "String" && (o = !1);
			}
			else a = h(i) && i.name === "Boolean";
			r[0] = a, r[1] = o, (a || u(r, "default")) && f.push(t);
		}
	}
	let m = [l, f];
	return v(e) && a.set(e, m), m;
}
function Qr(e) {
	return e[0] !== "$" && !ee(e);
}
var $r = (e) => e === "_" || e === "_ctx" || e === "$stable", ei = (e) => d(e) ? e.map(Li) : [Li(e)], ti = (e, t, n) => {
	if (t._n) return t;
	let r = bn((...e) => ei(t(...e)), n);
	return r._c = !1, r;
}, ni = (e, t, n) => {
	let r = e._ctx;
	for (let n in e) {
		if ($r(n)) continue;
		let i = e[n];
		if (h(i)) t[n] = ti(n, i, r);
		else if (i != null) {
			let e = ei(i);
			t[n] = () => e;
		}
	}
}, ri = (e, t) => {
	let n = ei(t);
	e.slots.default = () => n;
}, ii = (e, t, n) => {
	for (let r in t) (n || !$r(r)) && (e[r] = t[r]);
}, ai = (e, t, n) => {
	let r = e.slots = Wr();
	if (e.vnode.shapeFlag & 32) {
		let e = t._;
		e ? (ii(r, t, n), n && O(r, "_", e, !0)) : ni(t, r);
	} else t && ri(e, t);
}, oi = (e, n, r) => {
	let { vnode: i, slots: a } = e, o = !0, s = t;
	if (i.shapeFlag & 32) {
		let e = n._;
		e ? r && e === 1 ? o = !1 : ii(a, n, r) : (o = !n.$stable, ni(n, a)), s = n;
	} else n && (ri(e, n), s = { default: 1 });
	if (o) for (let e in a) !$r(e) && s[e] == null && delete a[e];
}, G = vi;
function si(e) {
	return ci(e);
}
function ci(e, i) {
	let a = le();
	a.__VUE__ = !0;
	let { insert: o, remove: s, patchProp: c, createElement: l, createText: u, createComment: d, setText: f, setElementText: p, parentNode: m, nextSibling: h, setScopeId: g = r, insertStaticContent: _ } = e, v = (e, t, n, r = null, i = null, a = null, o = void 0, s = null, c = !!t.dynamicChildren) => {
		if (e === t) return;
		e && !ki(e, t) && (r = ye(e), k(e, i, a, !0), e = null), t.patchFlag === -2 && (c = !1, t.dynamicChildren = null);
		let { type: l, ref: u, shapeFlag: d } = t;
		switch (l) {
			case yi:
				y(e, t, n, r);
				break;
			case bi:
				b(e, t, n, r);
				break;
			case xi:
				e ?? x(t, n, r, o);
				break;
			case K:
				ae(e, t, n, r, i, a, o, s, c);
				break;
			default: d & 1 ? w(e, t, n, r, i, a, o, s, c) : d & 6 ? D(e, t, n, r, i, a, o, s, c) : (d & 64 || d & 128) && l.process(e, t, n, r, i, a, o, s, c, A);
		}
		u != null && i ? Bn(u, e && e.ref, a, t || e, !t) : u == null && e && e.ref != null && Bn(e.ref, null, a, e, !0);
	}, y = (e, t, n, r) => {
		if (e == null) o(t.el = u(t.children), n, r);
		else {
			let n = t.el = e.el;
			t.children !== e.children && f(n, t.children);
		}
	}, b = (e, t, n, r) => {
		e == null ? o(t.el = d(t.children || ""), n, r) : t.el = e.el;
	}, x = (e, t, n, r) => {
		[e.el, e.anchor] = _(e.children, t, n, r, e.el, e.anchor);
	}, S = ({ el: e, anchor: t }, n, r) => {
		let i;
		for (; e && e !== t;) i = h(e), o(e, n, r), e = i;
		o(t, n, r);
	}, C = ({ el: e, anchor: t }) => {
		let n;
		for (; e && e !== t;) n = h(e), s(e), e = n;
		s(t);
	}, w = (e, t, n, r, i, a, o, s, c) => {
		if (t.type === "svg" ? o = "svg" : t.type === "math" && (o = "mathml"), e == null) te(t, n, r, i, a, o, s, c);
		else {
			let n = e.el && e.el._isVueCE ? e.el : null;
			try {
				n && n._beginPatch(), re(e, t, i, a, o, s, c);
			} finally {
				n && n._endPatch();
			}
		}
	}, te = (e, t, n, r, i, a, s, u) => {
		let d, f, { props: m, shapeFlag: h, transition: g, dirs: _ } = e;
		if (d = e.el = l(e.type, a, m && m.is, m), h & 8 ? p(d, e.children) : h & 16 && T(e.children, d, null, r, i, li(e, a), s, u), _ && xn(e, null, r, "created"), ne(d, e, e.scopeId, s, r), m) {
			for (let e in m) e !== "value" && !ee(e) && c(d, e, null, m[e], a, r);
			"value" in m && c(d, "value", null, m.value, a), (f = m.onVnodeBeforeMount) && Q(f, r, e);
		}
		_ && xn(e, null, r, "beforeMount");
		let v = di(i, g);
		v && g.beforeEnter(d), o(d, t, n), ((f = m && m.onVnodeMounted) || v || _) && G(() => {
			try {
				f && Q(f, r, e), v && g.enter(d), _ && xn(e, null, r, "mounted");
			} finally {}
		}, i);
	}, ne = (e, t, n, r, i) => {
		if (n && g(e, n), r) for (let t = 0; t < r.length; t++) g(e, r[t]);
		if (i) {
			let n = i.subTree;
			if (t === n || _i(n.type) && (n.ssContent === t || n.ssFallback === t)) {
				let t = i.vnode;
				ne(e, t, t.scopeId, t.slotScopeIds, i.parent);
			}
		}
	}, T = (e, t, n, r, i, a, o, s, c = 0) => {
		for (let l = c; l < e.length; l++) {
			let c = e[l] = s ? Ri(e[l]) : Li(e[l]);
			v(null, c, t, n, r, i, a, o, s);
		}
	}, re = (e, n, r, i, a, o, s) => {
		let l = n.el = e.el, { patchFlag: u, dynamicChildren: d, dirs: f } = n;
		u |= e.patchFlag & 16;
		let m = e.props || t, h = n.props || t, g;
		if (r && ui(r, !1), (g = h.onVnodeBeforeUpdate) && Q(g, r, n, e), f && xn(n, e, r, "beforeUpdate"), r && ui(r, !0), d && (!e.dynamicChildren || e.dynamicChildren.length !== d.length) && (u = 0, s = !1, d = null), (m.innerHTML && h.innerHTML == null || m.textContent && h.textContent == null) && p(l, ""), d ? E(e.dynamicChildren, d, l, r, i, li(n, a), o) : s || de(e, n, l, null, r, i, li(n, a), o, !1), u > 0) {
			if (u & 16) ie(l, m, h, r, a);
			else if (u & 2 && m.class !== h.class && c(l, "class", null, h.class, a), u & 4 && c(l, "style", m.style, h.style, a), u & 8) {
				let e = n.dynamicProps;
				for (let t = 0; t < e.length; t++) {
					let n = e[t], i = m[n], o = h[n];
					(o !== i || n === "value") && c(l, n, i, o, a, r);
				}
			}
			u & 1 && e.children !== n.children && p(l, n.children);
		} else !s && d == null && ie(l, m, h, r, a);
		((g = h.onVnodeUpdated) || f) && G(() => {
			g && Q(g, r, n, e), f && xn(n, e, r, "updated");
		}, i);
	}, E = (e, t, n, r, i, a, o) => {
		for (let s = 0; s < t.length; s++) {
			let c = e[s], l = t[s], u = c.el && (c.type === K || !ki(c, l) || c.shapeFlag & 198) ? m(c.el) : n;
			v(c, l, u, null, r, i, a, o, !0);
		}
	}, ie = (e, n, r, i, a) => {
		if (n !== r) {
			if (n !== t) for (let t in n) !ee(t) && !(t in r) && c(e, t, n[t], null, a, i);
			for (let t in r) {
				if (ee(t)) continue;
				let o = r[t], s = n[t];
				o !== s && t !== "value" && c(e, t, s, o, a, i);
			}
			"value" in r && c(e, "value", n.value, r.value, a);
		}
	}, ae = (e, t, n, r, i, a, s, c, l) => {
		let d = t.el = e ? e.el : u(""), f = t.anchor = e ? e.anchor : u(""), { patchFlag: p, dynamicChildren: m, slotScopeIds: h } = t;
		h && (c = c ? c.concat(h) : h), e == null ? (o(d, n, r), o(f, n, r), T(t.children || [], n, f, i, a, s, c, l)) : p > 0 && p & 64 && m && e.dynamicChildren && e.dynamicChildren.length === m.length ? (E(e.dynamicChildren, m, n, i, a, s, c), (t.key != null || i && t === i.subTree) && fi(e, t, !0)) : de(e, t, n, f, i, a, s, c, l);
	}, D = (e, t, n, r, i, a, o, s, c) => {
		t.slotScopeIds = s, e == null ? t.shapeFlag & 512 ? i.ctx.activate(t, n, r, o, c) : O(t, n, r, i, a, o, c) : se(e, t, c);
	}, O = (e, t, n, r, i, a, o) => {
		let s = e.component = Ui(e, r, i);
		if (Un(e) && (s.ctx.renderer = A), Zi(s, !1, o), s.asyncDep) {
			if (i && i.registerDep(s, ce, o), !e.el) {
				let r = s.subTree = Mi(bi);
				b(null, r, t, n), e.placeholder = r.el;
			}
		} else ce(s, e, t, n, i, a, o);
	}, se = (e, t, n) => {
		let r = t.component = e.component;
		if (zr(e, t, n)) {
			if (r.asyncDep && !r.asyncResolved) {
				ue(r, t, n);
				return;
			}
			r.next = t, r.update();
		} else t.el = e.el, r.vnode = t;
	}, ce = (e, t, n, r, i, a, o) => {
		let s = () => {
			if (e.isMounted) {
				let { next: t, bu: n, u: r, parent: s, vnode: c } = e;
				{
					let n = mi(e);
					if (n) {
						t && (t.el = c.el, ue(e, t, o)), n.asyncDep.then(() => {
							G(() => {
								e.isUnmounted || l();
							}, i);
						});
						return;
					}
				}
				let u = t, d;
				ui(e, !1), t ? (t.el = c.el, ue(e, t, o)) : t = c, n && oe(n), (d = t.props && t.props.onVnodeBeforeUpdate) && Q(d, s, t, c), ui(e, !0);
				let f = Ir(e), p = e.subTree;
				e.subTree = f, v(p, f, m(p.el), ye(p), e, i, a), t.el = f.el, u === null && Hr(e, f.el), r && G(r, i), (d = t.props && t.props.onVnodeUpdated) && G(() => Q(d, s, t, c), i);
			} else {
				let o, { el: s, props: c } = t, { bm: l, m: u, parent: d, root: f, type: p } = e, m = Hn(t);
				if (ui(e, !1), l && oe(l), !m && (o = c && c.onVnodeBeforeMount) && Q(o, d, t), ui(e, !0), s && Ce) {
					let t = () => {
						e.subTree = Ir(e), Ce(s, e.subTree, e, i, null);
					};
					m && p.__asyncHydrate ? p.__asyncHydrate(s, e, t) : t();
				} else {
					f.ce && f.ce._hasShadowRoot() && f.ce._injectChildStyle(p, e.parent ? e.parent.type : void 0);
					let o = e.subTree = Ir(e);
					v(null, o, n, r, e, i, a), t.el = o.el;
				}
				if (u && G(u, i), !m && (o = c && c.onVnodeMounted)) {
					let e = t;
					G(() => Q(o, d, e), i);
				}
				(t.shapeFlag & 256 || d && Hn(d.vnode) && d.vnode.shapeFlag & 256) && e.a && G(e.a, i), e.isMounted = !0, t = n = r = null;
			}
		};
		e.scope.on();
		let c = e.effect = new De(s);
		e.scope.off();
		let l = e.update = c.run.bind(c), u = e.job = c.runIfDirty.bind(c);
		u.i = e, u.id = e.uid, c.scheduler = () => un(u), ui(e, !0), l();
	}, ue = (e, t, n) => {
		t.component = e;
		let r = e.vnode.props;
		e.vnode = t, e.next = null, qr(e, t.props, r, n), oi(e, t.children, n), Ve(), pn(e), He();
	}, de = (e, t, n, r, i, a, o, s, c = !1) => {
		let l = e && e.children, u = e ? e.shapeFlag : 0, d = t.children, { patchFlag: f, shapeFlag: m } = t;
		if (f > 0) {
			if (f & 128) {
				pe(l, d, n, r, i, a, o, s, c);
				return;
			}
			if (f & 256) {
				fe(l, d, n, r, i, a, o, s, c);
				return;
			}
		}
		m & 8 ? (u & 16 && ve(l, i, a), d !== l && p(n, d)) : u & 16 ? m & 16 ? pe(l, d, n, r, i, a, o, s, c) : ve(l, i, a, !0) : (u & 8 && p(n, ""), m & 16 && T(d, n, r, i, a, o, s, c));
	}, fe = (e, t, r, i, a, o, s, c, l) => {
		e ||= n, t ||= n;
		let u = e.length, d = t.length, f = Math.min(u, d), p = 0;
		for (; p < f; p++) {
			let n = t[p] = l ? Ri(t[p]) : Li(t[p]);
			v(e[p], n, r, null, a, o, s, c, l);
		}
		u > d ? ve(e, a, o, !0, !1, f) : T(t, r, i, a, o, s, c, l, f);
	}, pe = (e, t, r, i, a, o, s, c, l) => {
		let u = 0, d = t.length, f = e.length - 1, p = d - 1;
		for (; u <= f && u <= p;) {
			let n = e[u], i = t[u] = l ? Ri(t[u]) : Li(t[u]);
			if (ki(n, i)) v(n, i, r, null, a, o, s, c, l);
			else break;
			u++;
		}
		for (; u <= f && u <= p;) {
			let n = e[f], i = t[p] = l ? Ri(t[p]) : Li(t[p]);
			if (ki(n, i)) v(n, i, r, null, a, o, s, c, l);
			else break;
			f--, p--;
		}
		if (u > f) {
			if (u <= p) {
				let e = p + 1, n = e < d ? t[e].el : i;
				for (; u <= p;) v(null, t[u] = l ? Ri(t[u]) : Li(t[u]), r, n, a, o, s, c, l), u++;
			}
		} else if (u > p) for (; u <= f;) k(e[u], a, o, !0), u++;
		else {
			let m = u, h = u, g = /* @__PURE__ */ new Map();
			for (u = h; u <= p; u++) {
				let e = t[u] = l ? Ri(t[u]) : Li(t[u]);
				e.key != null && g.set(e.key, u);
			}
			let _, y = 0, b = p - h + 1, x = !1, S = 0, C = Array(b);
			for (u = 0; u < b; u++) C[u] = 0;
			for (u = m; u <= f; u++) {
				let n = e[u];
				if (y >= b) {
					k(n, a, o, !0);
					continue;
				}
				let i;
				if (n.key != null) i = g.get(n.key);
				else for (_ = h; _ <= p; _++) if (C[_ - h] === 0 && ki(n, t[_])) {
					i = _;
					break;
				}
				i === void 0 ? k(n, a, o, !0) : (C[i - h] = u + 1, i >= S ? S = i : x = !0, v(n, t[i], r, null, a, o, s, c, l), y++);
			}
			let w = x ? pi(C) : n;
			for (_ = w.length - 1, u = b - 1; u >= 0; u--) {
				let e = h + u, n = t[e], f = t[e + 1], p = e + 1 < d ? f.el || gi(f) : i;
				C[u] === 0 ? v(null, n, r, p, a, o, s, c, l) : x && (_ < 0 || u !== w[_] ? me(n, r, p, 2) : _--);
			}
		}
	}, me = (e, t, n, r, i = null) => {
		let { el: a, type: c, transition: l, children: u, shapeFlag: d } = e;
		if (d & 6) {
			me(e.component.subTree, t, n, r);
			return;
		}
		if (d & 128) {
			e.suspense.move(t, n, r);
			return;
		}
		if (d & 64) {
			c.move(e, t, n, A);
			return;
		}
		if (c === K) {
			o(a, t, n);
			for (let e = 0; e < u.length; e++) me(u[e], t, n, r);
			o(e.anchor, t, n);
			return;
		}
		if (c === xi) {
			S(e, t, n);
			return;
		}
		if (r !== 2 && d & 1 && l) {
			if (r === 0) l.persisted && !a[Mn] ? o(a, t, n) : (l.beforeEnter(a), o(a, t, n), G(() => l.enter(a), i));
			else {
				let { leave: r, delayLeave: i, afterLeave: c } = l, u = () => {
					e.ctx.isUnmounted ? s(a) : o(a, t, n);
				}, d = () => {
					let e = a._isLeaving || !!a[Mn];
					a._isLeaving && a[Mn](!0), l.persisted && !e ? u() : r(a, () => {
						u(), c && c();
					});
				};
				i ? i(a, u, d) : d();
			}
		} else o(a, t, n);
	}, k = (e, t, n, r = !1, i = !1) => {
		let { type: a, props: o, ref: s, children: c, dynamicChildren: l, shapeFlag: u, patchFlag: d, dirs: f, cacheIndex: p, memo: m } = e;
		if (d === -2 && (i = !1), s != null && (Ve(), Bn(s, null, n, e, !0), He()), p != null && (t.renderCache[p] = void 0), u & 256) {
			t.ctx.deactivate(e);
			return;
		}
		let h = u & 1 && f, g = !Hn(e), _;
		if (g && (_ = o && o.onVnodeBeforeUnmount) && Q(_, t, e), u & 6) _e(e.component, n, r);
		else {
			if (u & 128) {
				e.suspense.unmount(n, r);
				return;
			}
			h && xn(e, null, t, "beforeUnmount"), u & 64 ? e.type.remove(e, t, n, A, r) : l && !l.hasOnce && (a !== K || d > 0 && d & 64) ? ve(l, t, n, !1, !0) : (a === K && d & 384 || !i && u & 16) && ve(c, t, n), r && he(e);
		}
		let v = m != null && p == null;
		(g && (_ = o && o.onVnodeUnmounted) || h || v) && G(() => {
			_ && Q(_, t, e), h && xn(e, null, t, "unmounted"), v && (e.el = null);
		}, n);
	}, he = (e) => {
		let { type: t, el: n, anchor: r, transition: i } = e;
		if (t === K) {
			ge(n, r);
			return;
		}
		if (t === xi) {
			C(e);
			return;
		}
		let a = () => {
			s(n), i && !i.persisted && i.afterLeave && i.afterLeave();
		};
		if (e.shapeFlag & 1 && i && !i.persisted) {
			let { leave: t, delayLeave: r } = i, o = () => t(n, a);
			r ? r(e.el, a, o) : o();
		} else a();
	}, ge = (e, t) => {
		let n;
		for (; e !== t;) n = h(e), s(e), e = n;
		s(t);
	}, _e = (e, t, n) => {
		let { bum: r, scope: i, job: a, subTree: o, um: s, m: c, a: l } = e;
		hi(c), hi(l), r && oe(r), i.stop(), a && (a.flags |= 8, k(o, e, t, n)), s && G(s, t), G(() => {
			e.isUnmounted = !0;
		}, t);
	}, ve = (e, t, n, r = !1, i = !1, a = 0) => {
		for (let o = a; o < e.length; o++) k(e[o], t, n, r, i);
	}, ye = (e) => {
		if (e.shapeFlag & 6) return ye(e.component.subTree);
		if (e.shapeFlag & 128) return e.suspense.next();
		let t = h(e.anchor || e.el), n = t && t[An];
		return n ? h(n) : t;
	}, be = !1, xe = (e, t, n) => {
		let r;
		e == null ? t._vnode && (k(t._vnode, null, null, !0), r = t._vnode.component) : v(t._vnode || null, e, t, null, null, null, n), t._vnode = e, be ||= (be = !0, pn(r), mn(), !1);
	}, A = {
		p: v,
		um: k,
		m: me,
		r: he,
		mt: O,
		mc: T,
		pc: de,
		pbc: E,
		n: ye,
		o: e
	}, Se, Ce;
	return i && ([Se, Ce] = i(A)), {
		render: xe,
		hydrate: Se,
		createApp: kr(xe, Se)
	};
}
function li({ type: e, props: t }, n) {
	return n === "svg" && e === "foreignObject" || n === "mathml" && e === "annotation-xml" && t && t.encoding && t.encoding.includes("html") ? void 0 : n;
}
function ui({ effect: e, job: t }, n) {
	n ? (e.flags |= 32, t.flags |= 4) : (e.flags &= -33, t.flags &= -5);
}
function di(e, t) {
	return (!e || e && !e.pendingBranch) && t && !t.persisted;
}
function fi(e, t, n = !1) {
	let r = e.children, i = t.children;
	if (d(r) && d(i)) for (let e = 0; e < r.length; e++) {
		let t = r[e], a = i[e];
		a.shapeFlag & 1 && !a.dynamicChildren && ((a.patchFlag <= 0 || a.patchFlag === 32) && (a = i[e] = Ri(i[e]), a.el = t.el), !n && a.patchFlag !== -2 && fi(t, a)), a.type === yi && (a.patchFlag === -1 && (a = i[e] = Ri(a)), a.el = t.el), a.type === bi && !a.el && (a.el = t.el);
	}
}
function pi(e) {
	let t = e.slice(), n = [0], r, i, a, o, s, c = e.length;
	for (r = 0; r < c; r++) {
		let c = e[r];
		if (c !== 0) {
			if (i = n[n.length - 1], e[i] < c) {
				t[r] = i, n.push(r);
				continue;
			}
			for (a = 0, o = n.length - 1; a < o;) s = a + o >> 1, e[n[s]] < c ? a = s + 1 : o = s;
			c < e[n[a]] && (a > 0 && (t[r] = n[a - 1]), n[a] = r);
		}
	}
	for (a = n.length, o = n[a - 1]; a-- > 0;) n[a] = o, o = t[o];
	return n;
}
function mi(e) {
	let t = e.subTree.component;
	if (t) return t.asyncDep && !t.asyncResolved ? t : mi(t);
}
function hi(e) {
	if (e) for (let t = 0; t < e.length; t++) e[t].flags |= 8;
}
function gi(e) {
	if (e.placeholder) return e.placeholder;
	let t = e.component;
	return t ? gi(t.subTree) : null;
}
var _i = (e) => e.__isSuspense;
function vi(e, t) {
	t && t.pendingBranch ? d(e) ? t.effects.push(...e) : t.effects.push(e) : fn(e);
}
var K = /* @__PURE__ */ Symbol.for("v-fgt"), yi = /* @__PURE__ */ Symbol.for("v-txt"), bi = /* @__PURE__ */ Symbol.for("v-cmt"), xi = /* @__PURE__ */ Symbol.for("v-stc"), Si = [], q = null;
function J(e = !1) {
	Si.push(q = e ? null : []);
}
function Ci() {
	Si.pop(), q = Si[Si.length - 1] || null;
}
var wi = 1;
function Ti(e, t = !1) {
	wi += e, e < 0 && q && t && (q.hasOnce = !0);
}
function Ei(e) {
	return e.dynamicChildren = wi > 0 ? q || n : null, Ci(), wi > 0 && q && q.push(e), e;
}
function Y(e, t, n, r, i, a) {
	return Ei(X(e, t, n, r, i, a, !0));
}
function Di(e, t, n, r, i) {
	return Ei(Mi(e, t, n, r, i, !0));
}
function Oi(e) {
	return e ? e.__v_isVNode === !0 : !1;
}
function ki(e, t) {
	return e.type === t.type && e.key === t.key;
}
var Ai = ({ key: e }) => e ?? null, ji = ({ ref: e, ref_key: t, ref_for: n }) => (typeof e == "number" && (e = "" + e), e == null ? null : g(e) || /* @__PURE__ */ z(e) || h(e) ? {
	i: _n,
	r: e,
	k: t,
	f: !!n
} : e);
function X(e, t = null, n = null, r = 0, i = null, a = e === K ? 0 : 1, o = !1, s = !1) {
	let c = {
		__v_isVNode: !0,
		__v_skip: !0,
		type: e,
		props: t,
		key: t && Ai(t),
		ref: t && ji(t),
		scopeId: vn,
		slotScopeIds: null,
		children: n,
		component: null,
		suspense: null,
		ssContent: null,
		ssFallback: null,
		dirs: null,
		transition: null,
		el: null,
		anchor: null,
		target: null,
		targetStart: null,
		targetAnchor: null,
		staticCount: 0,
		shapeFlag: a,
		patchFlag: r,
		dynamicProps: i,
		dynamicChildren: null,
		appContext: null,
		ctx: _n
	};
	return s ? (zi(c, n), a & 128 && e.normalize(c)) : n && (c.shapeFlag |= g(n) ? 8 : 16), wi > 0 && !o && q && (c.patchFlag > 0 || a & 6) && c.patchFlag !== 32 && q.push(c), c;
}
var Mi = Ni;
function Ni(e, t = null, n = null, r = 0, i = null, a = !1) {
	if ((!e || e === or) && (e = bi), Oi(e)) {
		let r = Fi(e, t, !0);
		return n && zi(r, n), wi > 0 && !a && q && (r.shapeFlag & 6 ? q[q.indexOf(e)] = r : q.push(r)), r.patchFlag = -2, r;
	}
	if (ia(e) && (e = e.__vccOpts), t) {
		t = Pi(t);
		let { class: e, style: n } = t;
		e && !g(e) && (t.class = k(e)), v(n) && (/* @__PURE__ */ Lt(n) && !d(n) && (n = s({}, n)), t.style = ue(n));
	}
	let o = g(e) ? 1 : _i(e) ? 128 : jn(e) ? 64 : v(e) ? 4 : h(e) ? 2 : 0;
	return X(e, t, n, r, i, o, a, !0);
}
function Pi(e) {
	return e ? /* @__PURE__ */ Lt(e) || Gr(e) ? s({}, e) : e : null;
}
function Fi(e, t, n = !1, r = !1) {
	let { props: i, ref: a, patchFlag: o, children: s, transition: c } = e, l = t ? Bi(i || {}, t) : i, u = {
		__v_isVNode: !0,
		__v_skip: !0,
		type: e.type,
		props: l,
		key: l && Ai(l),
		ref: t && t.ref ? n && a ? d(a) ? a.concat(ji(t)) : [a, ji(t)] : ji(t) : a,
		scopeId: e.scopeId,
		slotScopeIds: e.slotScopeIds,
		children: s,
		target: e.target,
		targetStart: e.targetStart,
		targetAnchor: e.targetAnchor,
		staticCount: e.staticCount,
		shapeFlag: e.shapeFlag,
		patchFlag: t && e.type !== K ? o === -1 ? 16 : o | 16 : o,
		dynamicProps: e.dynamicProps,
		dynamicChildren: e.dynamicChildren,
		appContext: e.appContext,
		dirs: e.dirs,
		transition: c,
		component: e.component,
		suspense: e.suspense,
		ssContent: e.ssContent && Fi(e.ssContent),
		ssFallback: e.ssFallback && Fi(e.ssFallback),
		placeholder: e.placeholder,
		el: e.el,
		anchor: e.anchor,
		ctx: e.ctx,
		ce: e.ce
	};
	return c && r && Fn(u, c.clone(u)), u;
}
function Ii(e = " ", t = 0) {
	return Mi(yi, null, e, t);
}
function Z(e = "", t = !1) {
	return t ? (J(), Di(bi, null, e)) : Mi(bi, null, e);
}
function Li(e) {
	return e == null || typeof e == "boolean" ? Mi(bi) : d(e) ? Mi(K, null, e.slice()) : Oi(e) ? Ri(e) : Mi(yi, null, String(e));
}
function Ri(e) {
	return e.el === null && e.patchFlag !== -1 || e.memo ? e : Fi(e);
}
function zi(e, t) {
	let n = 0, { shapeFlag: r } = e;
	if (t == null) t = null;
	else if (d(t)) n = 16;
	else if (typeof t == "object") {
		if (r & 65) {
			let n = t.default;
			n && (n._c && (n._d = !1), zi(e, n()), n._c && (n._d = !0));
			return;
		}
		{
			n = 32;
			let r = t._;
			!r && !Gr(t) ? t._ctx = _n : r === 3 && _n && (_n.slots._ === 1 ? t._ = 1 : (t._ = 2, e.patchFlag |= 1024));
		}
	} else if (h(t)) {
		if (r & 65) {
			zi(e, { default: t });
			return;
		}
		t = {
			default: t,
			_ctx: _n
		}, n = 32;
	} else t = String(t), r & 64 ? (n = 16, t = [Ii(t)]) : n = 8;
	e.children = t, e.shapeFlag |= n;
}
function Bi(...e) {
	let t = {};
	for (let n = 0; n < e.length; n++) {
		let r = e[n];
		for (let e in r) if (e === "class") t.class !== r.class && (t.class = k([t.class, r.class]));
		else if (e === "style") t.style = ue([t.style, r.style]);
		else if (a(e)) {
			let n = t[e], i = r[e];
			i && n !== i && !(d(n) && n.includes(i)) ? t[e] = n ? [].concat(n, i) : i : i == null && n == null && !o(e) && (t[e] = i);
		} else e !== "" && (t[e] = r[e]);
	}
	return t;
}
function Q(e, t, n, r = null) {
	V(e, t, 7, [n, r]);
}
var Vi = Dr(), Hi = 0;
function Ui(e, n, r) {
	let i = e.type, a = (n ? n.appContext : e.appContext) || Vi, o = {
		uid: Hi++,
		vnode: e,
		type: i,
		parent: n,
		appContext: a,
		root: null,
		next: null,
		subTree: null,
		effect: null,
		update: null,
		job: null,
		scope: new we(!0),
		render: null,
		proxy: null,
		exposed: null,
		exposeProxy: null,
		withProxy: null,
		provides: n ? n.provides : Object.create(a.provides),
		ids: n ? n.ids : [
			"",
			0,
			0
		],
		accessCache: null,
		renderCache: [],
		components: null,
		directives: null,
		propsOptions: Zr(i, a),
		emitsOptions: Pr(i, a),
		emit: null,
		emitted: null,
		propsDefaults: t,
		inheritAttrs: i.inheritAttrs,
		ctx: t,
		data: t,
		props: t,
		attrs: t,
		slots: t,
		refs: t,
		setupState: t,
		setupContext: null,
		suspense: r,
		suspenseId: r ? r.pendingId : 0,
		asyncDep: null,
		asyncResolved: !1,
		isMounted: !1,
		isUnmounted: !1,
		isDeactivated: !1,
		bc: null,
		c: null,
		bm: null,
		m: null,
		bu: null,
		u: null,
		um: null,
		bum: null,
		da: null,
		a: null,
		rtg: null,
		rtc: null,
		ec: null,
		sp: null
	};
	return o.ctx = { _: o }, o.root = n ? n.root : o, o.emit = Mr.bind(null, o), e.ce && e.ce(o), o;
}
var $ = null, Wi = () => $ || _n, Gi, Ki;
{
	let e = le(), t = (t, n) => {
		let r;
		return (r = e[t]) || (r = e[t] = []), r.push(n), (e) => {
			r.length > 1 ? r.forEach((t) => t(e)) : r[0](e);
		};
	};
	Gi = t("__VUE_INSTANCE_SETTERS__", (e) => $ = e), Ki = t("__VUE_SSR_SETTERS__", (e) => Xi = e);
}
var qi = (e) => {
	let t = $;
	return Gi(e), e.scope.on(), () => {
		e.scope.off(), Gi(t);
	};
}, Ji = () => {
	$ && $.scope.off(), Gi(null);
};
function Yi(e) {
	return e.vnode.shapeFlag & 4;
}
var Xi = !1;
function Zi(e, t = !1, n = !1) {
	t && Ki(t);
	let { props: r, children: i } = e.vnode, a = Yi(e);
	Kr(e, r, a, t), ai(e, i, n || t);
	let o = a ? Qi(e, t) : void 0;
	return t && Ki(!1), o;
}
function Qi(e, t) {
	let n = e.type;
	e.accessCache = /* @__PURE__ */ Object.create(null), e.proxy = new Proxy(e.ctx, dr);
	let { setup: r } = n;
	if (r) {
		Ve();
		let n = e.setupContext = r.length > 1 ? na(e) : null, i = qi(e), a = $t(r, e, 0, [e.props, n]), o = y(a);
		if (He(), i(), (o || e.sp) && !Hn(e) && Ln(e), o) {
			if (a.then(Ji, Ji), t) return a.then((n) => {
				Ki(!0);
				try {
					$i(e, n, t);
				} finally {
					Ki(!1);
				}
			}).catch((t) => {
				en(t, e, 0);
			});
			e.asyncDep = a;
		} else $i(e, a, t);
	} else ea(e, t);
}
function $i(e, t, n) {
	h(t) ? e.type.__ssrInlineRender ? e.ssrRender = t : e.render = t : v(t) && (e.setupState = Wt(t)), ea(e, n);
}
function ea(e, t, n) {
	let i = e.type;
	e.render ||= i.render || r;
	{
		let t = qi(e);
		Ve();
		try {
			mr(e);
		} finally {
			He(), t();
		}
	}
}
var ta = { get(e, t) {
	return P(e, "get", ""), e[t];
} };
function na(e) {
	return {
		attrs: new Proxy(e.attrs, ta),
		slots: e.slots,
		emit: e.emit,
		expose: (t) => {
			e.exposed = t || {};
		}
	};
}
function ra(e) {
	return e.exposed ? e.exposeProxy ||= new Proxy(Wt(Rt(e.exposed)), {
		get(t, n) {
			if (n in t) return t[n];
			if (n in lr) return lr[n](e);
		},
		has(e, t) {
			return t in e || t in lr;
		}
	}) : e.proxy;
}
function ia(e) {
	return h(e) && "__vccOpts" in e;
}
var aa = (e, t) => /* @__PURE__ */ Kt(e, t, Xi), oa = "3.5.42", sa = void 0, ca = typeof window < "u" && window.trustedTypes;
if (ca) try {
	sa = /* @__PURE__ */ ca.createPolicy("vue", { createHTML: (e) => e });
} catch {}
var la = sa ? (e) => sa.createHTML(e) : (e) => e, ua = "http://www.w3.org/2000/svg", da = "http://www.w3.org/1998/Math/MathML", fa = typeof document < "u" ? document : null, pa = fa && /* @__PURE__ */ fa.createElement("template"), ma = {
	insert: (e, t, n) => {
		t.insertBefore(e, n || null);
	},
	remove: (e) => {
		let t = e.parentNode;
		t && t.removeChild(e);
	},
	createElement: (e, t, n, r) => {
		let i = t === "svg" ? fa.createElementNS(ua, e) : t === "mathml" ? fa.createElementNS(da, e) : n ? fa.createElement(e, { is: n }) : fa.createElement(e);
		return e === "select" && r && r.multiple != null && i.setAttribute("multiple", r.multiple), i;
	},
	createText: (e) => fa.createTextNode(e),
	createComment: (e) => fa.createComment(e),
	setText: (e, t) => {
		e.nodeValue = t;
	},
	setElementText: (e, t) => {
		e.textContent = t;
	},
	parentNode: (e) => e.parentNode,
	nextSibling: (e) => e.nextSibling,
	querySelector: (e) => fa.querySelector(e),
	setScopeId(e, t) {
		e.setAttribute(t, "");
	},
	insertStaticContent(e, t, n, r, i, a) {
		let o = n ? n.previousSibling : t.lastChild;
		if (i && (i === a || i.nextSibling)) for (; t.insertBefore(i.cloneNode(!0), n), i !== a && (i = i.nextSibling););
		else {
			pa.innerHTML = la(r === "svg" ? `<svg>${e}</svg>` : r === "mathml" ? `<math>${e}</math>` : e);
			let i = pa.content;
			if (r === "svg" || r === "mathml") {
				let e = i.firstChild;
				for (; e.firstChild;) i.appendChild(e.firstChild);
				i.removeChild(e);
			}
			t.insertBefore(i, n);
		}
		return [o ? o.nextSibling : t.firstChild, n ? n.previousSibling : t.lastChild];
	}
}, ha = /* @__PURE__ */ Symbol("_vtc");
function ga(e, t, n) {
	let r = e[ha];
	r && (t = (t ? [t, ...r] : [...r]).join(" ")), t == null ? e.removeAttribute("class") : n ? e.setAttribute("class", t) : e.className = t;
}
var _a = /* @__PURE__ */ Symbol("_vod"), va = /* @__PURE__ */ Symbol("_vsh"), ya = /* @__PURE__ */ Symbol(""), ba = /(?:^|;)\s*display\s*:/;
function xa(e, t, n) {
	let r = e.style, i = g(n), a = !1;
	if (n && !i) {
		if (t) {
			if (g(t)) for (let e of t.split(";")) {
				let t = e.slice(0, e.indexOf(":")).trim();
				n[t] ?? Ca(r, t, "");
			}
			else for (let e in t) n[e] ?? Ca(r, e, "");
		}
		for (let i in n) {
			i === "display" && (a = !0);
			let o = n[i];
			o == null ? Ca(r, i, "") : Da(e, i, !g(t) && t ? t[i] : void 0, o) || Ca(r, i, o);
		}
	} else if (i) {
		if (t !== n) {
			let e = r[ya];
			e && (n += ";" + e), r.cssText = n, a = ba.test(n);
		}
	} else t && e.removeAttribute("style");
	_a in e && (e[_a] = a ? r.display : "", e[va] && (r.display = "none"));
}
var Sa = /\s*!important$/;
function Ca(e, t, n) {
	if (d(n)) n.forEach((n) => Ca(e, t, n));
	else if (n ??= "", t.startsWith("--")) Sa.test(n) ? e.setProperty(t, n.replace(Sa, ""), "important") : e.setProperty(t, n);
	else {
		let r = Ea(e, t);
		Sa.test(n) ? e.setProperty(E(r), n.replace(Sa, ""), "important") : e[r] = n;
	}
}
var wa = [
	"Webkit",
	"Moz",
	"ms"
], Ta = {};
function Ea(e, t) {
	let n = Ta[t];
	if (n) return n;
	let r = T(t);
	if (r !== "filter" && r in e) return Ta[t] = r;
	r = ie(r);
	for (let n = 0; n < wa.length; n++) {
		let i = wa[n] + r;
		if (i in e) return Ta[t] = i;
	}
	return t;
}
function Da(e, t, n, r) {
	return e.tagName === "TEXTAREA" && (t === "width" || t === "height") && g(r) && n === r;
}
var Oa = "http://www.w3.org/1999/xlink";
function ka(e, t, n, r, i, a = ge(t)) {
	r && t.startsWith("xlink:") ? n == null ? e.removeAttributeNS(Oa, t.slice(6, t.length)) : e.setAttributeNS(Oa, t, n) : n == null || a && !_e(n) ? e.removeAttribute(t) : e.setAttribute(t, a ? "" : _(n) ? String(n) : n);
}
function Aa(e, t, n, r, i) {
	if (t === "innerHTML" || t === "textContent") {
		n != null && (e[t] = t === "innerHTML" ? la(n) : n);
		return;
	}
	let a = e.tagName;
	if (t === "value" && a !== "PROGRESS" && !a.includes("-")) {
		let r = a === "OPTION" ? e.getAttribute("value") || "" : e.value, i = n == null ? e.type === "checkbox" ? "on" : "" : String(n);
		(r !== i || !("_value" in e)) && (e.value = i), n ?? e.removeAttribute(t), e._value = n;
		return;
	}
	let o = !1;
	if (n === "" || n == null) {
		let r = typeof e[t];
		r === "boolean" ? n = _e(n) : n == null && r === "string" ? (n = "", o = !0) : r === "number" && (n = 0, o = !0);
	}
	try {
		e[t] = n;
	} catch {}
	o && e.removeAttribute(i || t);
}
function ja(e, t, n, r) {
	e.addEventListener(t, n, r);
}
function Ma(e, t, n, r) {
	e.removeEventListener(t, n, r);
}
var Na = /* @__PURE__ */ Symbol("_vei");
function Pa(e, t, n, r, i = null) {
	let a = e[Na] || (e[Na] = {}), o = a[t];
	if (r && o) o.value = r;
	else {
		let [n, s] = La(t);
		r ? ja(e, n, a[t] = Va(r, i), s) : o && (Ma(e, n, o, s), a[t] = void 0);
	}
}
var Fa = /(Once|Passive|Capture)$/, Ia = /^on:?(?:Once|Passive|Capture)$/;
function La(e) {
	let t, n;
	for (; (n = e.match(Fa)) && !Ia.test(e);) t ||= {}, e = e.slice(0, e.length - n[1].length), t[n[1].toLowerCase()] = !0;
	return [e[2] === ":" ? e.slice(3) : E(e.slice(2)), t];
}
var Ra = 0, za = /* @__PURE__ */ Promise.resolve(), Ba = () => Ra ||= (za.then(() => Ra = 0), Date.now());
function Va(e, t) {
	let n = (e) => {
		if (!e._vts) e._vts = Date.now();
		else if (e._vts <= n.attached) return;
		let r = n.value;
		if (d(r)) {
			let n = e.stopImmediatePropagation;
			e.stopImmediatePropagation = () => {
				n.call(e), e._stopped = !0;
			};
			let i = r.slice(), a = [e];
			for (let n = 0; n < i.length && !e._stopped; n++) {
				let e = i[n];
				e && V(e, t, 5, a);
			}
		} else V(r, t, 5, [e]);
	};
	return n.value = e, n.attached = Ba(), n;
}
var Ha = (e) => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && e.charCodeAt(2) > 96 && e.charCodeAt(2) < 123, Ua = (e, t, n, r, i, s) => {
	let c = i === "svg";
	t === "class" ? ga(e, r, c) : t === "style" ? xa(e, n, r) : a(t) ? o(t) || Pa(e, t, n, r, s) : (t[0] === "." ? (t = t.slice(1), 1) : t[0] === "^" ? (t = t.slice(1), 0) : Wa(e, t, r, c)) ? (Aa(e, t, r), !e.tagName.includes("-") && (t === "value" || t === "checked" || t === "selected") && ka(e, t, r, c, s, t !== "value")) : e._isVueCE && (Ga(e, t) || e._def.__asyncLoader && (/[A-Z]/.test(t) || !g(r))) ? Aa(e, T(t), r, s, t) : (t === "true-value" ? e._trueValue = r : t === "false-value" && (e._falseValue = r), ka(e, t, r, c));
};
function Wa(e, t, n, r) {
	if (r) return !!(t === "innerHTML" || t === "textContent" || t in e && Ha(t) && h(n));
	if (t === "spellcheck" || t === "draggable" || t === "translate" || t === "autocorrect" || t === "sandbox" && e.tagName === "IFRAME" || t === "form" || t === "list" && e.tagName === "INPUT" || t === "type" && e.tagName === "TEXTAREA") return !1;
	if (t === "width" || t === "height") {
		let t = e.tagName;
		if (t === "IMG" || t === "VIDEO" || t === "CANVAS" || t === "SOURCE") return !1;
	}
	return Ha(t) && g(n) ? !1 : t in e;
}
function Ga(e, t) {
	let n = e._def.props;
	if (!n) return !1;
	let r = T(t);
	return Array.isArray(n) ? n.some((e) => T(e) === r) : Object.keys(n).some((e) => T(e) === r);
}
var Ka = [
	"ctrl",
	"shift",
	"alt",
	"meta"
], qa = {
	stop: (e) => e.stopPropagation(),
	prevent: (e) => e.preventDefault(),
	self: (e) => e.target !== e.currentTarget,
	ctrl: (e) => !e.ctrlKey,
	shift: (e) => !e.shiftKey,
	alt: (e) => !e.altKey,
	meta: (e) => !e.metaKey,
	left: (e) => "button" in e && e.button !== 0,
	middle: (e) => "button" in e && e.button !== 1,
	right: (e) => "button" in e && e.button !== 2,
	exact: (e, t) => Ka.some((n) => e[`${n}Key`] && !t.includes(n))
}, Ja = (e, t) => {
	if (!e) return e;
	let n = e._withMods ||= {}, r = t.join(".");
	return n[r] || (n[r] = ((n, ...r) => {
		for (let e = 0; e < t.length; e++) {
			let r = qa[t[e]];
			if (r && r(n, t)) return;
		}
		return e(n, ...r);
	}));
}, Ya = /* @__PURE__ */ s({ patchProp: Ua }, ma), Xa;
function Za() {
	return Xa ||= si(Ya);
}
var Qa = ((...e) => {
	let t = Za().createApp(...e), { mount: n } = t;
	return t.mount = (e) => {
		let r = eo(e);
		if (!r) return;
		let i = t._component;
		!h(i) && !i.render && !i.template && (i.template = r.innerHTML), r.nodeType === 1 && (r.textContent = "");
		let a = n(r, !1, $a(r));
		return r instanceof Element && (r.removeAttribute("v-cloak"), r.setAttribute("data-v-app", "")), a;
	}, t;
});
function $a(e) {
	if (e instanceof SVGElement) return "svg";
	if (typeof MathMLElement == "function" && e instanceof MathMLElement) return "mathml";
}
function eo(e) {
	return g(e) ? document.querySelector(e) : e;
}
//#endregion
//#region src/CheckInTaskEditor.vue?vue&type=script&setup=true&lang.ts
var to = [
	"open",
	"title",
	"aria-label",
	"close-label"
], no = {
	key: 0,
	class: "gci-editor",
	"data-task-editor": ""
}, ro = { class: "gci-editor-section" }, io = { class: "gci-form-grid" }, ao = ["label"], oo = [
	"model-value",
	"aria-invalid",
	"aria-label"
], so = ["label"], co = ["model-value", "aria-label"], lo = [
	"model-value",
	"label",
	"description",
	"aria-label"
], uo = [
	"title",
	"description",
	"expanded"
], fo = { class: "gci-checkin-fields" }, po = { class: "gci-platform-list" }, mo = ["label", "help"], ho = [
	"id",
	"model-value",
	"options",
	"disabled",
	"placeholder",
	"aria-label",
	"onChange"
], go = { class: "gci-credential-list" }, _o = ["label", "help"], vo = [
	"id",
	"model-value",
	"placeholder",
	"aria-label",
	"onChange"
], yo = [
	"id",
	"model-value",
	"label",
	"aria-label",
	"onChange"
], bo = { class: "gci-notification-settings" }, xo = [
	"model-value",
	"label",
	"description",
	"aria-label"
], So = ["label", "help"], Co = ["model-value", "aria-label"], wo = { class: "gci-schedules" }, To = { class: "gci-section-heading" }, Eo = {
	key: 0,
	class: "gci-schedule-list"
}, Do = [
	"data-schedule-id",
	"onDragover",
	"onDrop"
], Oo = { class: "gci-schedule-head" }, ko = [
	"aria-label",
	"title",
	"onDragstart",
	"onKeydown"
], Ao = [
	"aria-expanded",
	"aria-controls",
	"onClick"
], jo = { class: "gci-schedule-summary-main" }, Mo = {
	class: "gci-schedule-chevron",
	"aria-hidden": "true"
}, No = ["id"], Po = { class: "gci-schedule-layout" }, Fo = { class: "gci-schedule-days" }, Io = { class: "gci-field-label" }, Lo = ["aria-label"], Ro = [
	"aria-pressed",
	"aria-label",
	"title",
	"onClick"
], zo = { class: "gci-field gci-schedule-time" }, Bo = [
	"id",
	"model-value",
	"aria-label",
	"onChange"
], Vo = { class: "gci-schedule-actions" }, Ho = [
	"model-value",
	"aria-label",
	"onChange"
], Uo = ["label", "onClick"], Wo = {
	key: 1,
	class: "gci-empty-schedules"
}, Go = ["label", "disabled"], Ko = {
	key: 0,
	class: "gci-error",
	role: "alert"
}, qo = {
	slot: "footer",
	class: "gci-modal-footer-actions"
}, Jo = ["label", "busy"], Yo = ["label", "disabled"], Xo = /* @__PURE__ */ In({
	__name: "CheckInTaskEditor",
	props: {
		open: { type: Boolean },
		task: {},
		tasks: {},
		platforms: {},
		timeZoneId: {},
		submitting: { type: Boolean },
		error: {},
		nameError: {},
		translate: { type: Function }
	},
	emits: [
		"close",
		"save",
		"invalid",
		"nameChange"
	],
	setup(e, { emit: t }) {
		let n = e, r = t, i = /* @__PURE__ */ B(null), a = /* @__PURE__ */ B({}), o = /* @__PURE__ */ B({}), s = /* @__PURE__ */ B(!0), c = /* @__PURE__ */ B([]), l = /* @__PURE__ */ B(""), u = /* @__PURE__ */ B(""), d = /* @__PURE__ */ B(""), f = /* @__PURE__ */ B(""), p = 0, m = aa(() => [
			g("day.0", {}, "周日"),
			g("day.1", {}, "周一"),
			g("day.2", {}, "周二"),
			g("day.3", {}, "周三"),
			g("day.4", {}, "周四"),
			g("day.5", {}, "周五"),
			g("day.6", {}, "周六")
		]), h = aa(() => [
			g("common.sun", {}, "日"),
			g("common.mon", {}, "一"),
			g("common.tue", {}, "二"),
			g("common.wed", {}, "三"),
			g("common.thu", {}, "四"),
			g("common.fri", {}, "五"),
			g("common.sat", {}, "六")
		]);
		En(() => `${n.open}:${n.task?.id || "new"}`, () => {
			n.open ? v() : i.value = null;
		}, { immediate: !0 });
		function g(e, t = {}, r = "") {
			return n.translate(e, t, r);
		}
		function _(e) {
			let t = e.detail;
			return Array.isArray(t) && t.length ? t[0] : t === void 0 ? e.target?.modelValue : t;
		}
		function v() {
			let e = n.task;
			i.value = e ? {
				id: e.id,
				name: e.name,
				remark: e.remark || "",
				enabled: e.enabled,
				games: Object.fromEntries(Object.entries(e.games || {}).map(([e, t]) => [e, [...t]])),
				schedules: (e.schedules || []).map((e) => ({
					...e,
					days: [...e.days]
				})),
				notification: {
					enabled: e.notification?.enabled === !0,
					smtpTo: e.notification?.smtpTo || ""
				}
			} : {
				name: "",
				remark: "",
				enabled: !0,
				games: {},
				schedules: [],
				notification: {
					enabled: !1,
					smtpTo: ""
				}
			}, a.value = Object.fromEntries(n.platforms.map((e) => [e.id, ""])), o.value = Object.fromEntries(n.platforms.map((e) => [e.id, !1])), s.value = !0, d.value = "", f.value = "", c.value = [];
		}
		function y(e, t) {
			i.value && (i.value[e] = t), e === "name" && (f.value = "", d.value = "", r("nameChange"));
		}
		function b(e, t) {
			if (!i.value) return;
			let n = _(t), r = Array.isArray(n) ? n.map(String) : [];
			r.length ? i.value.games[e] = r : delete i.value.games[e];
		}
		function x(e) {
			return g(`field.${e}_games_description`, {}, "可留空。");
		}
		function S(e) {
			return e === "cn" ? "cnCookie" : e === "os" ? "osCookie" : e === "skland" ? "sklandToken" : e === "skport" ? "skportToken" : e === "kuro" ? "kuroToken" : e;
		}
		function C(e) {
			return g(`field.${S(e)}_description`, {}, "填写该平台凭据。");
		}
		function w(e) {
			return g(`field.${S(e)}_placeholder`, {}, "");
		}
		function ee() {
			if (!i.value || i.value.schedules.length >= 30) return;
			let e = globalThis.crypto?.randomUUID, t = typeof e == "function" ? e.call(globalThis.crypto) : `draft-${Date.now().toString(36)}-${(++p).toString(36)}`, n = {
				id: t,
				days: [
					1,
					2,
					3,
					4,
					5
				],
				enabled: !0,
				time: "09:00"
			};
			i.value.schedules.push(n), c.value = [...c.value, t];
		}
		function te(e) {
			if (!i.value) return;
			let [t] = i.value.schedules.splice(e, 1);
			t && (c.value = c.value.filter((e) => e !== t.id));
		}
		function ne(e) {
			return c.value.includes(e);
		}
		function T(e) {
			c.value = ne(e) ? c.value.filter((t) => t !== e) : [...c.value, e];
		}
		function re(e, t) {
			e.days = e.days.includes(t) ? e.days.filter((e) => e !== t) : [...e.days, t].sort((e, t) => e - t);
		}
		function E(e, t) {
			l.value = t, u.value = "", e.dataTransfer && (e.dataTransfer.effectAllowed = "move", e.dataTransfer.setData("text/plain", t));
		}
		function ie(e, t) {
			if (!i.value || !e || !t || e === t) return;
			let n = i.value.schedules, r = n.findIndex((t) => t.id === e);
			if (r < 0) return;
			let [a] = n.splice(r, 1), o = n.findIndex((e) => e.id === t);
			n.splice(o < 0 ? n.length : o, 0, a);
		}
		function ae(e, t) {
			ie(e.dataTransfer?.getData("text/plain") || l.value, t), l.value = "", u.value = "";
		}
		function D() {
			l.value = "", u.value = "";
		}
		function oe(e, t) {
			if (!i.value || e.key !== "ArrowUp" && e.key !== "ArrowDown") return;
			e.preventDefault();
			let n = i.value.schedules.findIndex((e) => e.id === t), r = n + (e.key === "ArrowUp" ? -1 : 1);
			n < 0 || r < 0 || r >= i.value.schedules.length || ([i.value.schedules[n], i.value.schedules[r]] = [i.value.schedules[r], i.value.schedules[n]]);
		}
		function O(e, t) {
			a.value[e] = t, t.trim() && (o.value[e] = !1);
		}
		function se(e, t) {
			o.value[e] = t, t && (a.value[e] = "");
		}
		function ce() {
			if (!i.value || n.submitting) return;
			let e = i.value;
			if (!e.name.trim() || e.name.trim().length > 100) {
				let e = g("error.task_name_invalid", {}, "请输入不超过 100 个字符的任务名称。");
				f.value = e, r("invalid", e);
				return;
			}
			if (n.tasks.some((t) => t.id !== e.id && t.name.toLocaleLowerCase() === e.name.trim().toLocaleLowerCase())) {
				let e = g("error.task_name_duplicate", {}, "签到任务名称已存在。");
				f.value = e, r("invalid", e);
				return;
			}
			if (new TextEncoder().encode(e.remark).length > 512) {
				d.value = g("error.task_remark_invalid", {}, "备注不能超过 512 字节。");
				return;
			}
			if (e.schedules.some((e) => e.days.length === 0 || !/^\d{2}:\d{2}$/.test(e.time))) {
				d.value = g("error.schedule_settings_invalid", {}, "请检查计划时间和执行星期。");
				return;
			}
			if (e.notification.smtpTo.length > 4096) {
				d.value = g("error.smtp_recipient_invalid", {}, "SMTP 收件人内容过长。");
				return;
			}
			d.value = "";
			let t = {};
			for (let e of n.platforms) {
				let n = a.value[e.id] || "";
				n.trim() ? t[e.id] = {
					action: "set",
					value: n
				} : o.value[e.id] ? t[e.id] = { action: "clear" } : t[e.id] = { action: "keep" };
			}
			r("save", {
				...e,
				id: e.id,
				name: e.name.trim(),
				remark: e.remark.trim(),
				schedules: e.schedules.map((e) => ({
					...e,
					days: [...e.days]
				})),
				notification: {
					...e.notification,
					smtpTo: e.notification.smtpTo.trim()
				},
				secrets: t
			});
		}
		return (t, n) => e.open ? (J(), Y("nxp-modal", {
			key: 0,
			open: e.open,
			title: e.task ? g("editor.edit_title", {}, "编辑签到任务") : g("editor.new_title", {}, "新建签到任务"),
			"aria-label": e.task ? g("editor.edit_title", {}, "编辑签到任务") : g("editor.new_title", {}, "新建签到任务"),
			size: "wide",
			locked: "",
			footer: "",
			"close-label": g("action.close", {}, "关闭"),
			onClose: n[9] ||= (e) => r("close")
		}, [i.value ? (J(), Y("div", no, [
			X("section", ro, [X("div", io, [X("nxp-field", {
				label: g("field.name", {}, "任务名称"),
				required: ""
			}, [X("nxp-text-input", {
				id: "gci-task-name",
				"model-value": i.value.name,
				required: "",
				"aria-invalid": f.value || e.nameError ? "true" : "false",
				"aria-label": g("field.name", {}, "任务名称"),
				onChange: n[0] ||= (e) => y("name", String(_(e) || "")),
				"onUpdate:modelValue": n[1] ||= (e) => y("name", String(_(e) || ""))
			}, null, 40, oo)], 8, ao), X("nxp-field", { label: g("field.remark", {}, "备注") }, [X("nxp-text-area", {
				id: "gci-task-remark",
				"model-value": i.value.remark,
				rows: "2",
				"aria-label": g("field.remark", {}, "备注"),
				onChange: n[2] ||= (e) => y("remark", String(_(e) || ""))
			}, null, 40, co)], 8, so)]), X("nxp-switch-setting", {
				id: "gci-task-enabled",
				"model-value": i.value.enabled,
				label: g("field.task_enabled", {}, "启用此任务"),
				description: g("field.task_enabled_help", {}, "停用后不会按计划自动签到。"),
				"aria-label": g("field.task_enabled", {}, "启用此任务"),
				onChange: n[3] ||= (e) => y("enabled", _(e))
			}, null, 40, lo)]),
			X("nxp-collapsible-card", {
				class: "gci-checkin-settings",
				title: g("field.checkin_settings", {}, "签到设置"),
				description: g("field.checkin_settings_help", {}, "按需配置五个平台的游戏和凭据，本任务触发时将对所选游戏执行签到。"),
				"panel-id": "gci-checkin-settings",
				surface: "secondary",
				expanded: s.value,
				onToggle: n[6] ||= (e) => s.value = _(e)
			}, [X("div", fo, [
				X("div", po, [(J(!0), Y(K, null, sr(e.platforms, (e) => (J(), Y("nxp-field", {
					key: `${e.id}-games`,
					label: g("field.platform_games", { platform: e.name }, `${e.name} 签到游戏`),
					help: x(e.id)
				}, [X("nxp-select", {
					id: `gci-games-${e.id}`,
					"model-value": i.value.games[e.id] || [],
					options: e.games.map((e) => ({
						value: e.id,
						label: e.name
					})),
					multiple: !0,
					disabled: e.games.length === 0,
					placeholder: g("common.choose", {}, "请选择"),
					"aria-label": g("field.platform_games", { platform: e.name }, `${e.name} 签到游戏`),
					onChange: (t) => b(e.id, t)
				}, null, 40, ho)], 8, mo))), 128))]),
				X("div", go, [(J(!0), Y(K, null, sr(e.platforms, (t) => (J(), Y("div", {
					key: t.id,
					class: "gci-credential-row"
				}, [X("nxp-field", {
					label: g("field.credential", { platform: t.name }, `${t.name} 凭据`),
					help: C(t.id)
				}, [X("nxp-text-input", {
					id: `gci-secret-${t.id}`,
					"model-value": a.value[t.id] || "",
					type: "password",
					autocomplete: "new-password",
					placeholder: e.task?.credentials?.[t.id] ? g("field.secret_configured", {}, "已保存，留空保留") : w(t.id),
					"aria-label": g("field.credential", { platform: t.name }, `${t.name} 凭据`),
					onChange: (e) => O(t.id, String(_(e) || ""))
				}, null, 40, vo)], 8, _o), e.task?.credentials?.[t.id] ? (J(), Y("nxp-switch-setting", {
					key: 0,
					id: `gci-clear-${t.id}`,
					"model-value": o.value[t.id] === !0,
					label: g("field.secret_clear", {}, "清除已保存凭据"),
					"aria-label": `${t.name} · ${g("field.secret_clear", {}, "清除已保存凭据")}`,
					onChange: (e) => se(t.id, _(e))
				}, null, 40, yo)) : Z("", !0)]))), 128))]),
				X("section", bo, [X("nxp-switch-setting", {
					id: "gci-notification-enabled",
					"model-value": i.value.notification.enabled,
					label: g("field.notifications_enabled", {}, "启用通知"),
					description: g("field.notifications_help", {}, "使用宿主全局 Webhook 与 SMTP 设置。"),
					"aria-label": g("field.notifications_enabled", {}, "启用通知"),
					onChange: n[4] ||= (e) => i.value.notification.enabled = _(e)
				}, null, 40, xo), X("nxp-field", {
					label: g("field.smtp_to", {}, "SMTP 收件人"),
					help: g("field.smtp_to_help", {}, "留空时继承宿主全局 SMTP 收件人。")
				}, [X("nxp-text-input", {
					id: "gci-smtp-to",
					"model-value": i.value.notification.smtpTo,
					autocomplete: "email",
					"aria-label": g("field.smtp_to", {}, "SMTP 收件人"),
					onChange: n[5] ||= (e) => i.value.notification.smtpTo = String(_(e) || "")
				}, null, 40, Co)], 8, So)])
			])], 40, uo),
			X("section", wo, [
				X("header", To, [X("div", null, [X("h3", null, A(g("field.schedule", {}, "定时计划")), 1), X("p", null, A(g("field.schedule_help", { zone: e.timeZoneId }, `按本机时区 ${e.timeZoneId} 执行；应用关闭期间错过的时间不会补跑。`)), 1)])]),
				i.value.schedules.length ? (J(), Y("div", Eo, [(J(!0), Y(K, null, sr(i.value.schedules, (e, t) => (J(), Y("article", {
					key: e.id,
					class: k(["gci-schedule-card", {
						"is-open": ne(e.id),
						"is-dragging": l.value === e.id,
						"is-drop-target": u.value === e.id
					}]),
					"data-schedule-id": e.id,
					onDragover: Ja((t) => u.value = e.id, ["prevent"]),
					onDragleave: n[7] ||= Ja((e) => u.value = "", ["self"]),
					onDrop: Ja((t) => ae(t, e.id), ["prevent"])
				}, [X("div", Oo, [X("span", {
					class: "gci-drag-handle",
					role: "button",
					tabindex: "0",
					draggable: "true",
					"aria-label": g("common.reorder.schedule", { index: t + 1 }, `调整计划 ${t + 1} 的顺序`),
					title: g("common.drag_to_reorder", {}, "拖动以调整顺序"),
					onDragstart: Ja((t) => E(t, e.id), ["stop"]),
					onDragend: D,
					onKeydown: (t) => oe(t, e.id)
				}, "⠿", 40, ko), X("button", {
					class: "gci-schedule-summary",
					type: "button",
					"aria-expanded": ne(e.id),
					"aria-controls": `gci-schedule-${e.id}`,
					onClick: (t) => T(e.id)
				}, [X("span", jo, [X("strong", null, A(g("schedule.label", { index: t + 1 }, `定时 ${t + 1}`)), 1), X("span", null, A(e.time) + " · " + A(g("schedule.days_count", { count: e.days.length }, `${e.days.length} 天`)), 1)]), X("span", Mo, A(ne(e.id) ? "⌄" : "›"), 1)], 8, Ao)]), ne(e.id) ? (J(), Y("div", {
					key: 0,
					id: `gci-schedule-${e.id}`,
					class: "gci-schedule-details"
				}, [X("div", Po, [X("div", Fo, [X("span", Io, A(g("field.schedule_days", {}, "执行周期（可多选）")), 1), X("div", {
					class: "gci-day-buttons",
					role: "group",
					"aria-label": g("field.schedule_days", {}, "执行星期")
				}, [(J(!0), Y(K, null, sr(m.value, (t, n) => (J(), Y("button", {
					key: n,
					class: "gci-day-button",
					type: "button",
					"aria-pressed": e.days.includes(n),
					"aria-label": t,
					title: t,
					onClick: (t) => re(e, n)
				}, A(h.value[n]), 9, Ro))), 128))], 8, Lo)]), X("label", zo, [X("span", null, A(g("field.schedule_time", {}, "执行时间")), 1), X("nxp-time-picker", {
					id: `gci-time-${e.id}`,
					"model-value": e.time,
					"aria-label": g("field.schedule_time", {}, "时间"),
					onChange: (t) => e.time = String(_(t) || e.time)
				}, null, 40, Bo)])]), X("footer", Vo, [X("nxp-switch", {
					"model-value": e.enabled,
					"semantic-role": "switch",
					"aria-label": `${g("field.schedule_enabled", {}, "启用此计划")} ${t + 1}`,
					onChange: (t) => e.enabled = _(t)
				}, null, 40, Ho), X("nxp-button", {
					label: g("action.remove_schedule", {}, "删除计划"),
					variant: "ghost",
					onClick: (e) => te(t)
				}, null, 8, Uo)])], 8, No)) : Z("", !0)], 42, Do))), 128))])) : (J(), Y("p", Wo, A(g("empty.schedules", {}, "还没有定时计划")), 1)),
				X("nxp-button", {
					label: `+ ${g("action.add_schedule", {}, "添加定时")}`,
					variant: "ghost",
					disabled: i.value.schedules.length >= 30,
					onClick: ee
				}, null, 8, Go)
			]),
			d.value || e.error ? (J(), Y("p", Ko, A(d.value || e.error), 1)) : Z("", !0)
		])) : Z("", !0), X("div", qo, [X("nxp-button", {
			label: e.submitting ? g("status.saving", {}, "保存中…") : g("action.save", {}, "保存"),
			tone: "primary",
			busy: e.submitting,
			onClick: ce
		}, null, 8, Jo), X("nxp-button", {
			label: g("action.cancel", {}, "取消"),
			variant: "ghost",
			disabled: e.submitting,
			onClick: n[8] ||= (e) => r("close")
		}, null, 8, Yo)])], 40, to)) : Z("", !0);
	}
}), Zo = ["aria-label"], Qo = [
	"data-task-id",
	"onDragover",
	"onDrop"
], $o = { class: "gci-task-row-main" }, es = [
	"aria-label",
	"title",
	"onDragstart",
	"onKeydown"
], ts = {
	class: "gci-task-avatar",
	"aria-hidden": "true"
}, ns = { class: "gci-task-copy" }, rs = { class: "gci-task-heading" }, is = {
	key: 0,
	class: "gci-task-remark"
}, as = { class: "gci-task-meta" }, os = ["label", "tone"], ss = ["label", "tone"], cs = ["label", "tone"], ls = ["label"], us = ["label"], ds = { class: "gci-task-actions" }, fs = [
	"label",
	"disabled",
	"onClick"
], ps = ["label", "onClick"], ms = [
	"label",
	"disabled",
	"onClick"
], hs = {
	key: 0,
	class: "gci-run-history"
}, gs = { class: "gci-run-list" }, _s = { class: "gci-run-entry-head" }, vs = ["label", "tone"], ys = { key: 0 }, bs = /* @__PURE__ */ In({
	__name: "CheckInTaskList",
	props: {
		tasks: {},
		platforms: {},
		translate: { type: Function }
	},
	emits: [
		"run",
		"edit",
		"remove",
		"reorder"
	],
	setup(e, { emit: t }) {
		let n = e, r = t, i = /* @__PURE__ */ B(""), a = /* @__PURE__ */ B("");
		function o(e, t = {}, r = "") {
			return n.translate(e, t, r);
		}
		function s(e) {
			return Array.from(e.trim())[0]?.toLocaleUpperCase() || "?";
		}
		function c(e) {
			return Object.values(e.games || {}).reduce((e, t) => e + t.length, 0);
		}
		function l(e) {
			if (!e) return o("task.no_next_run", {}, "未安排下次运行");
			let t = new Date(e);
			return Number.isNaN(t.getTime()) ? o("task.no_next_run", {}, "未安排下次运行") : o("task.next_run_badge", { time: t.toLocaleString(void 0, {
				month: "numeric",
				day: "numeric",
				hour: "2-digit",
				minute: "2-digit"
			}) }, `下次 ${t.toLocaleString(void 0, {
				month: "numeric",
				day: "numeric",
				hour: "2-digit",
				minute: "2-digit"
			})}`);
		}
		function u(e) {
			return e === "running" ? "blue" : e === "success" ? "ok" : e === "partial" ? "warn" : e === "failed" || e === "cancelled" ? "bad" : "muted";
		}
		function d(e) {
			if (!e) return o("task.no_results", {}, "没有运行记录");
			let t = new Date(e);
			return Number.isNaN(t.getTime()) ? e : t.toLocaleString();
		}
		function f(e, t) {
			return n.platforms.find((t) => t.id === e)?.games.find((e) => e.id === t)?.name || t;
		}
		function p(e, t) {
			i.value = t, a.value = "", e.dataTransfer && (e.dataTransfer.effectAllowed = "move", e.dataTransfer.setData("text/plain", t));
		}
		function m(e, t) {
			if (!e || !t || e === t) return;
			let i = n.tasks.map((e) => e.id), a = i.indexOf(e), o = i.indexOf(t);
			if (a < 0 || o < 0) return;
			let [s] = i.splice(a, 1), c = i.indexOf(t);
			i.splice(c, 0, s), r("reorder", i);
		}
		function h(e, t) {
			m(e.dataTransfer?.getData("text/plain") || i.value, t), i.value = "", a.value = "";
		}
		function g() {
			i.value = "", a.value = "";
		}
		function _(e, t) {
			if (e.key !== "ArrowUp" && e.key !== "ArrowDown") return;
			e.preventDefault();
			let i = n.tasks.map((e) => e.id), a = i.indexOf(t), o = a + (e.key === "ArrowUp" ? -1 : 1);
			o < 0 || o >= i.length || ([i[a], i[o]] = [i[o], i[a]], r("reorder", i));
		}
		return (t, n) => (J(), Y("div", {
			class: "gci-task-list",
			role: "list",
			"aria-label": o("page.title", {}, "签到任务")
		}, [(J(!0), Y(K, null, sr(e.tasks, (e) => (J(), Y("article", {
			key: e.id,
			class: k(["gci-task-row", {
				"is-dragging": i.value === e.id,
				"is-drop-target": a.value === e.id
			}]),
			"data-task-id": e.id,
			role: "listitem",
			onDragover: Ja((t) => a.value = e.id, ["prevent"]),
			onDragleave: n[0] ||= Ja((e) => a.value = "", ["self"]),
			onDrop: Ja((t) => h(t, e.id), ["prevent"])
		}, [X("div", $o, [
			X("span", {
				class: "gci-drag-handle",
				role: "button",
				tabindex: "0",
				draggable: "true",
				"aria-label": o("common.reorder.task", { name: e.name }, `调整 ${e.name} 的顺序`),
				title: o("common.drag_to_reorder", {}, "拖动以调整顺序"),
				onDragstart: Ja((t) => p(t, e.id), ["stop"]),
				onDragend: g,
				onKeydown: (t) => _(t, e.id)
			}, "⠿", 40, es),
			X("span", ts, A(s(e.name)), 1),
			X("div", ns, [
				X("div", rs, [X("h2", null, A(e.name), 1)]),
				e.remark ? (J(), Y("p", is, A(e.remark), 1)) : Z("", !0),
				X("div", as, [
					X("nxp-badge", {
						label: e.enabled ? o("status.enabled", {}, "已启用") : o("status.disabled", {}, "已停用"),
						tone: e.enabled ? "ok" : "muted"
					}, null, 8, os),
					e.recentRun ? (J(), Y("nxp-badge", {
						key: 0,
						label: o(`status.${e.recentRun.status}`, {}, e.recentRun.status),
						tone: u(e.recentRun.status)
					}, null, 8, ss)) : Z("", !0),
					X("nxp-badge", {
						label: e.notification?.enabled ? o("status.notifications_on", {}, "通知已开启") : o("status.notifications_off", {}, "通知已关闭"),
						tone: e.notification?.enabled ? "blue" : "muted"
					}, null, 8, cs),
					X("nxp-badge", {
						label: o("task.games_count", { count: c(e) }, `${c(e)} 个游戏`),
						tone: "muted"
					}, null, 8, ls),
					X("nxp-badge", {
						label: l(e.nextRunAt),
						tone: "blue"
					}, null, 8, us)
				])
			]),
			X("div", ds, [
				X("nxp-button", {
					label: o("action.run", {}, "立即签到"),
					variant: "ghost",
					disabled: e.isRunning,
					onClick: (t) => r("run", e)
				}, null, 8, fs),
				X("nxp-button", {
					label: o("action.edit", {}, "编辑签到"),
					variant: "ghost",
					onClick: (t) => r("edit", e)
				}, null, 8, ps),
				X("nxp-button", {
					label: o("action.delete", {}, "删除签到"),
					tone: "danger",
					variant: "ghost",
					disabled: e.isRunning,
					onClick: (t) => r("remove", e)
				}, null, 8, ms)
			])
		]), e.runs?.length ? (J(), Y("details", hs, [X("summary", null, A(o("action.show_results", {}, "运行记录")) + " · " + A(e.runs.length), 1), X("div", gs, [(J(!0), Y(K, null, sr(e.runs, (e) => (J(), Y("section", {
			key: e.id,
			class: "gci-run-entry"
		}, [X("header", _s, [X("span", null, A(d(e.completedAt || e.startedAt)), 1), X("nxp-badge", {
			label: o(`status.${e.status}`, {}, e.status),
			tone: u(e.status)
		}, null, 8, vs)]), e.results?.length ? (J(), Y("ul", ys, [(J(!0), Y(K, null, sr(e.results, (e, t) => (J(), Y("li", { key: `${e.platform}-${e.gameCode}-${t}` }, [X("span", null, A(f(e.platform, e.gameCode)), 1), X("span", null, A(e.message), 1)]))), 128))])) : Z("", !0)]))), 128))])])) : Z("", !0)], 42, Qo))), 128))], 8, Zo));
	}
}), xs = {
	class: "gci-page",
	"data-game-check-in-page": ""
}, Ss = { class: "gci-page-header" }, Cs = { class: "gci-page-header-copy" }, ws = { class: "gci-page-header-eyebrow" }, Ts = { class: "gci-page-header-description" }, Es = { class: "gci-page-header-actions" }, Ds = ["label"], Os = {
	key: 0,
	class: "gci-error",
	role: "alert"
}, ks = {
	key: 1,
	class: "gci-loading",
	role: "status"
}, As = ["title", "description"], js = ["label"], Ms = [
	"title",
	"locked",
	"closeable",
	"close-label"
], Ns = { class: "gci-confirm-message" }, Ps = {
	slot: "footer",
	class: "gci-modal-footer-actions"
}, Fs = ["label", "disabled"], Is = ["label", "busy"], Ls = /* @__PURE__ */ In({
	__name: "GameCheckInPage",
	props: { host: {} },
	setup(e) {
		let t = e, n = /* @__PURE__ */ B(null), r = /* @__PURE__ */ B(!0), i = /* @__PURE__ */ B(!1), a = /* @__PURE__ */ B(!1), o = /* @__PURE__ */ B(null), s = /* @__PURE__ */ B(""), c = /* @__PURE__ */ B(""), l = /* @__PURE__ */ B(""), u = /* @__PURE__ */ B(null), d = /* @__PURE__ */ B(!1), f = new AbortController(), p = null, m = !1, h = !1, g = aa(() => n.value?.tasks || []), _ = aa(() => n.value?.platforms || []), v = (e, n = {}, r = "") => t.host.i18n.t(e, n, r);
		function y(e, t = {}, n = "") {
			return v(e, t, n);
		}
		function b(e) {
			let t = e;
			if (typeof t?.code == "string" && t.code) return t.code;
			let n = t?.data;
			return typeof n?.code == "string" && n.code ? n.code : typeof n?.error == "string" ? n.error : "";
		}
		function x(e, t) {
			let n = b(e);
			return n ? y(`error.${n}`, {}, t) : t;
		}
		async function S(e = !1) {
			if (!(h || m)) {
				h = !0;
				try {
					let e = await t.host.api.get("state", f.signal);
					if (m) return;
					n.value = {
						tasks: Array.isArray(e?.tasks) ? e.tasks : [],
						platforms: Array.isArray(e?.platforms) ? e.platforms : [],
						timeZoneId: typeof e?.timeZoneId == "string" ? e.timeZoneId : ""
					}, s.value = "";
				} catch (t) {
					!m && e && (s.value = x(t, y("error.state_failed", {}, "签到任务读取失败，请稍后重试。")));
				} finally {
					h = !1, e && !m && (r.value = !1);
				}
			}
		}
		function C(e = null) {
			l.value = "", o.value = e, c.value = "", a.value = !0;
		}
		function w() {
			i.value || (a.value = !1, o.value = null, c.value = "");
		}
		async function ee(e) {
			if (!i.value) {
				i.value = !0, c.value = "";
				try {
					e.id ? await t.host.api.put("tasks", e, f.signal) : await t.host.api.post("tasks", e, f.signal), a.value = !1, o.value = null, await S(), t.host.ui?.toast(y("toast.saved", {}, "签到任务已保存。"), "success");
				} catch (e) {
					let n = b(e), r = x(e, y("error.save_failed", {}, "任务保存失败，请检查填写内容后重试。"));
					["task_name_invalid", "task_name_duplicate"].includes(n) ? (l.value = r, c.value = "") : c.value = r, t.host.ui?.toast(r, "error");
				} finally {
					i.value = !1;
				}
			}
		}
		async function te(e) {
			if (!n.value || e.length !== n.value.tasks.length) return;
			let r = new Map(n.value.tasks.map((e) => [e.id, e]));
			if (new Set(e).size !== e.length || e.some((e) => !r.has(e))) return;
			let i = n.value.tasks;
			n.value = {
				...n.value,
				tasks: e.map((e) => r.get(e))
			};
			try {
				await t.host.api.put("tasks/order", { taskIds: e }, f.signal), await S();
			} catch (e) {
				n.value = {
					...n.value,
					tasks: i
				}, s.value = x(e, y("error.task_order_save_failed", {}, "任务顺序保存失败。"));
			}
		}
		async function ne(e) {
			try {
				await t.host.api.post("tasks/run", { taskId: e.id }, f.signal), await S(), t.host.ui?.toast(y("toast.run_started", {}, "签到已开始。"), "info");
			} catch (e) {
				s.value = x(e, y("error.run_failed", {}, "签到启动失败，请稍后重试。"));
			}
		}
		async function T() {
			let e = u.value;
			if (e && !d.value) {
				d.value = !0;
				try {
					await t.host.api.delete("tasks", { taskId: e.id }, f.signal), u.value = null, o.value?.id === e.id && w(), await S(), t.host.ui?.toast(y("toast.deleted", {}, "签到任务已删除。"), "success");
				} catch (e) {
					s.value = x(e, y("error.delete_failed", {}, "任务删除失败。")), t.host.ui?.toast(s.value, "error");
				} finally {
					d.value = !1;
				}
			}
		}
		return Zn(() => {
			S(!0), p = setInterval(() => void S(), 5e3);
		}), er(() => {
			m = !0, f.abort(), p && clearInterval(p);
		}), (e, f) => (J(), Y("section", xs, [
			X("header", Ss, [X("div", Cs, [
				X("div", ws, A(y("page.title", {}, "签到")), 1),
				X("h2", null, A(y("page.title", {}, "签到")), 1),
				X("p", Ts, A(y("page.description", {}, "管理多平台签到任务和运行计划。")), 1)
			]), X("div", Es, [X("nxp-button", {
				label: y("action.add_task", {}, "添加签到任务"),
				tone: "primary",
				type: "button",
				onClick: f[0] ||= (e) => C()
			}, null, 8, Ds)])]),
			s.value ? (J(), Y("p", Os, A(s.value), 1)) : r.value ? (J(), Y("p", ks, A(y("status.loading", {}, "正在读取…")), 1)) : Z("", !0),
			g.value.length ? (J(), Di(bs, {
				key: 2,
				tasks: g.value,
				platforms: _.value,
				translate: v,
				onRun: ne,
				onEdit: C,
				onRemove: f[1] ||= (e) => u.value = e,
				onReorder: te
			}, null, 8, ["tasks", "platforms"])) : !r.value && !s.value ? (J(), Y("nxp-empty-state", {
				key: 3,
				title: y("empty.title", {}, "还没有签到任务"),
				description: y("empty.description", {}, "创建任务后设置游戏、凭据和定时计划。")
			}, [X("nxp-button", {
				label: y("action.add_task", {}, "添加签到任务"),
				tone: "primary",
				type: "button",
				onClick: f[2] ||= (e) => C()
			}, null, 8, js)], 8, As)) : Z("", !0),
			Mi(Xo, {
				open: a.value,
				task: o.value,
				tasks: n.value?.tasks || [],
				platforms: _.value,
				"time-zone-id": n.value?.timeZoneId || "",
				submitting: i.value,
				error: c.value,
				"name-error": l.value,
				translate: v,
				onClose: w,
				onSave: ee,
				onInvalid: f[3] ||= (e) => t.host.ui?.toast(e, "error"),
				onNameChange: f[4] ||= (e) => {
					l.value = "", c.value = "";
				}
			}, null, 8, [
				"open",
				"task",
				"tasks",
				"platforms",
				"time-zone-id",
				"submitting",
				"error",
				"name-error"
			]),
			u.value ? (J(), Y("nxp-modal", {
				key: 4,
				open: "",
				footer: "",
				title: y("action.delete", {}, "删除签到"),
				locked: d.value,
				closeable: !d.value,
				"close-label": y("action.close", {}, "关闭"),
				onClose: f[6] ||= (e) => !d.value && (u.value = null)
			}, [X("p", Ns, A(y("task.delete_confirm", {}, "删除此任务、计划和凭据？")) + " — " + A(u.value.name), 1), X("div", Ps, [X("nxp-button", {
				label: y("action.cancel", {}, "取消"),
				variant: "ghost",
				disabled: d.value,
				onClick: f[5] ||= (e) => u.value = null
			}, null, 8, Fs), X("nxp-button", {
				label: y("action.confirm", {}, "确定"),
				tone: "danger",
				busy: d.value,
				onClick: T
			}, null, 8, Is)])], 40, Ms)) : Z("", !0)
		]));
	}
});
//#endregion
//#region src/main.ts
function Rs(e) {
	let t = null, n = e.routes.register("tasks", (n, r, i) => {
		t?.unmount();
		let a = document.querySelector("#view");
		a && (t = Qa(Ls, { host: i || e }), t.mount(a));
	}), r = e.nav.register({
		id: "check-in-tasks",
		title: e.i18n.t("nav.title", {}, "签到"),
		route: "tasks",
		icon: "check",
		order: -100
	}), i = e.lifecycle.onDispose(() => {
		t?.unmount(), t = null;
	});
	return { dispose() {
		t?.unmount(), t = null, i?.dispose?.(), n?.dispose?.(), r?.dispose?.();
	} };
}
//#endregion
export { Rs as activate };
