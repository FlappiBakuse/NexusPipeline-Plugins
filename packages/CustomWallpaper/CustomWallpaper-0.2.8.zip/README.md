# 自定义壁纸

`custom-wallpaper` v0.2.6 使用 NexusPipeline Plugin API 1.6 与 Frontend API 1.5：壁纸配置、单文件与总量配额、文件头校验、SHA256 去重、排序、当前壁纸、按时间或 Web 会话轮换、配色推导和插件自有 Web API 全部由插件实现，宿主只提供通用插件资产存储、二进制 Web API 传输与通用外观表面。插件通过 `nxp-collapsible-card`、`nxp-switch-setting`、`nxp-select`、`nxp-number-input`、`nxp-range`、`nxp-file-picker`、`nxp-badge`、`nxp-sortable-list` 和 `nxp-drag-handle` 等公开元素渲染设置卡片，样式使用插件自有 `cw-*` 命名空间与宿主 `--nx-*` design token。

壁纸运行时属于插件前端模块本身：打开宿主页面后立即推进一次 Web 会话轮换、读取插件状态、应用背景与配色，并建立按时间轮换计时与低频对账；重新加载 Web UI 或打开新的 Web UI 会话会推进一次 startup 轮换，定时轮换仍由时间间隔驱动。设置卡片只提供配置界面，进入或离开设置页面不会清除壁纸，也不会改变当前壁纸。按时间轮换在任意页面继续生效。设置卡片遵循宿主统一的展开置顶规则，两个开关使用 `nxp-switch-list` 分组，与设置页的开关外观一致；状态徽章与删除按钮通过公开元素的 `label` 属性传文案。

插件校验图片类型、文件魔数、单文件 8192 KB 上限、32 张数量上限和 256 MiB 总容量，并在前端根据图片内容生成自适应强调色与主界面内容卡片表面色；启用壁纸后仍可使用宿主主题切换按钮。卡片与侧边栏透明度可在 0% 至 50% 之间调节，浅色、深色和跟随系统主题均保持有效。

升级到 v0.2.0 时，宿主会把 `config/appearance.json`、`user-assets/appearance/wallpapers/` 与外观轮换游标一次性搬迁到插件命名空间（保留原文件），插件在初始化时导入壁纸、顺序、当前壁纸、轮换方式、显示效果与已保存配色，随后删除搬迁载荷。
